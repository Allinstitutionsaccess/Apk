import { onValue, Query, DatabaseReference } from "firebase/database";

export function qs(
  ref: DatabaseReference | Query,
  callback: (snapshot: any) => void,
  cancelCallback?: (error: any) => void
) {
  return onValue(ref, callback, cancelCallback);
}
