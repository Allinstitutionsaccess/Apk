import { useState, FormEvent } from "react";
import { ChevronLeft, EyeOff, Eye, ArrowRight } from "lucide-react";
import { createUserWithEmailAndPassword, updateProfile } from "firebase/auth";
import { auth, db } from "../firebase";
import { ref, get, set, update } from "firebase/database";

interface RegisterProps {
  onNavigate: (view: string) => void;
}

export default function Register({ onNavigate }: RegisterProps) {
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [inviteCode, setInviteCode] = useState(() => {
    const params = new URLSearchParams(window.location.search);
    return params.get("ref") || params.get("invite") || "";
  });
  const [showPassword, setShowPassword] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleSubmit = async (e: FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError(null);

    try {
      const res = await createUserWithEmailAndPassword(auth, email, password);
      await updateProfile(res.user, { displayName: name });

      let referredBy: string | null = null;
      const refCodeClean = inviteCode.trim().toUpperCase();

      if (refCodeClean) {
        const usersRef = ref(db, "users");
        const usersSnap = await get(usersRef);
        if (usersSnap.exists()) {
          const allUsers = usersSnap.val();
          const referrerEntry = Object.entries(allUsers).find(
            ([_, u]: any) => u.inviteCode === refCodeClean
          );
          if (referrerEntry) {
            referredBy = referrerEntry[0];
          } else {
            setError(`Referral code "${refCodeClean}" was not found, so no referral will be credited. You can still continue using the app.`);
          }
        }
      }

      const userInviteCode = `EDU-${res.user.uid.slice(-8).toUpperCase()}`;
      await set(ref(db, `users/${res.user.uid}`), {
        name,
        email,
        inviteCode: userInviteCode,
        referredBy,
        referralRewardSent: false,
        createdAt: new Date().toISOString(),
      });

      alert("Account created successfully!");
      onNavigate("login");
    } catch (err: any) {
      setError(err.message || "Registration failed");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div
      className="flex flex-col relative min-h-screen pt-10 px-5"
      style={{
        backgroundImage: "radial-gradient(circle at 50% 0%, rgba(204,255,51,0.15) 0%, rgba(10,11,9,1) 55%)",
      }}
    >
      <header className="flex justify-between items-center mb-6">
        <button
          onClick={() => onNavigate("login")}
          className="w-10 h-10 rounded-full bg-white/5 flex items-center justify-center border border-white/10"
        >
          <ChevronLeft size={18} />
        </button>
        <span className="font-space font-black text-xl tracking-tighter text-[#cf3]">
          Edutech
        </span>
        <div className="w-10" />
      </header>

      <main className="flex-1 flex flex-col">
        <h1 className="text-3xl font-bold mb-2 tracking-tight">Create Account</h1>
        <p className="text-gray-400 text-sm mb-8">
          Join thousands of learners on Edutech today.
        </p>

        {error && (
          <div className="w-full p-3 mb-4 rounded-xl bg-red-500/10 border border-red-500/20 text-red-500 text-xs text-center">
            {error}
          </div>
        )}

        <form onSubmit={handleSubmit} className="w-full space-y-4">
          <div className="grid gap-1.5">
            <label className="text-sm font-medium text-gray-200">Full Name</label>
            <input
              type="text"
              value={name}
              onChange={(e) => setName(e.target.value)}
              className="bg-white rounded-xl px-4 py-3 text-black font-medium focus:ring-2 focus:ring-[#cf3] outline-none"
              placeholder="John Doe"
              required
            />
          </div>

          <div className="grid gap-1.5">
            <label className="text-sm font-medium text-gray-200">Email address</label>
            <input
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className="bg-white rounded-xl px-4 py-3 text-black font-medium focus:ring-2 focus:ring-[#cf3] outline-none"
              placeholder="example@gmail.com"
              required
            />
          </div>

          <div className="grid gap-1.5">
            <label className="text-sm font-medium text-gray-200">Password</label>
            <div className="relative">
              <input
                type={showPassword ? "text" : "password"}
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="bg-white rounded-xl px-4 py-3 text-black font-medium w-full focus:ring-2 focus:ring-[#cf3] outline-none"
                placeholder="Min. 6 characters"
                required
              />
              <button
                type="button"
                onClick={() => setShowPassword(!showPassword)}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-500"
              >
                {showPassword ? <EyeOff size={20} /> : <Eye size={20} />}
              </button>
            </div>
          </div>

          <div className="grid gap-1.5">
            <label className="text-sm font-medium text-gray-200">
              Invite Code <span className="text-white/30 text-xs font-normal">(Optional)</span>
            </label>
            <input
              type="text"
              value={inviteCode}
              onChange={(e) => setInviteCode(e.target.value)}
              className="bg-white rounded-xl px-4 py-3 text-black font-medium focus:ring-2 focus:ring-[#cf3] outline-none"
              placeholder="Enter referral code (if any)"
            />
          </div>

          <button
            type="submit"
            disabled={loading}
            className="w-full bg-[#cf3] text-black font-semibold rounded-full py-4 flex items-center justify-center gap-2 hover:bg-[#b8e62e] transition mt-2"
          >
            {loading ? (
              "Creating..."
            ) : (
              <>
                Create Account <ArrowRight size={18} />
              </>
            )}
          </button>
        </form>

        <p className="text-sm text-gray-400 text-center mt-8">
          Already have an account?{" "}
          <button
            onClick={() => onNavigate("login")}
            className="text-[#cf3] font-semibold ml-1"
          >
            Sign in
          </button>
        </p>
      </main>
    </div>
  );
}
