import { useState, FormEvent } from "react";
import { ChevronLeft, Mail, EyeOff, Eye, ArrowRight } from "lucide-react";
import { signInWithEmailAndPassword, signInWithPopup, GoogleAuthProvider, createUserWithEmailAndPassword } from "firebase/auth";
import { auth, db } from "../firebase";
import { ref, get, set, update } from "firebase/database";
import { ADMIN_EMAIL, ADMIN_PASSWORD } from "../data";

interface LoginProps {
  onNavigate: (view: string) => void;
  onLoginSuccess: (user: any) => void;
}

export default function Login({ onNavigate, onLoginSuccess }: LoginProps) {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleSubmit = async (e: FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError(null);

    const isAdminLocal = email.trim().toLowerCase() === ADMIN_EMAIL.toLowerCase() && password === ADMIN_PASSWORD;

    try {
      if (isAdminLocal) {
        // Try authenticating through Firebase Auth first
        try {
          const res = await signInWithEmailAndPassword(auth, email, password);
          onLoginSuccess({
            uid: res.user.uid,
            email: res.user.email || ADMIN_EMAIL,
            name: "Admin",
            isAdmin: true,
          });
        } catch {
          // If auth user doesn't exist, try creating him or bypass
          try {
            const res = await createUserWithEmailAndPassword(auth, email, password);
            await set(ref(db, `users/${res.user.uid}`), {
              name: "Admin",
              email: ADMIN_EMAIL,
              isAdmin: true,
              createdAt: new Date().toISOString(),
            });
            onLoginSuccess({
              uid: res.user.uid,
              email: ADMIN_EMAIL,
              name: "Admin",
              isAdmin: true,
            });
          } catch (err: any) {
            console.warn("Admin auth bypass used", err);
            onLoginSuccess({
              uid: "admin_local",
              email: ADMIN_EMAIL,
              name: "Admin",
              isAdmin: true,
            });
          }
        }
        onNavigate("admin");
      } else {
        const res = await signInWithEmailAndPassword(auth, email, password);
        const userRef = ref(db, `users/${res.user.uid}`);
        const userSnap = await get(userRef);
        let userData = userSnap.exists() ? userSnap.val() : {};
        onLoginSuccess({
          uid: res.user.uid,
          email: res.user.email || "",
          name: userData.name || res.user.displayName || res.user.email?.split("@")[0] || "User",
          isAdmin: userData.isAdmin || false,
          phone: userData.phone,
          inviteCode: userData.inviteCode,
          profilePicture: userData.profilePicture,
          devices: userData.devices || {},
        });
        onNavigate("home");
      }
    } catch (err: any) {
      setError(err.message || "Login failed");
    } finally {
      setLoading(false);
    }
  };

  const handleGoogleLogin = async () => {
    const provider = new GoogleAuthProvider();
    try {
      const res = await signInWithPopup(auth, provider);
      const userRef = ref(db, `users/${res.user.uid}`);
      const userSnap = await get(userRef);
      let referralBy: string | null = null;

      if (!userSnap.exists()) {
        const inviteCodeParam = new URLSearchParams(window.location.search).get("ref") || "";
        if (inviteCodeParam) {
          const usersRef = ref(db, "users");
          const usersSnap = await get(usersRef);
          if (usersSnap.exists()) {
            const allUsers = usersSnap.val();
            const referrerEntry = Object.entries(allUsers).find(
              ([_, u]: any) => u.inviteCode === inviteCodeParam.trim().toUpperCase()
            );
            if (referrerEntry) {
              referralBy = referrerEntry[0];
            }
          }
        }

        const generatedInvite = `EDU-${res.user.uid.slice(-8).toUpperCase()}`;
        const newUserData = {
          name: res.user.displayName || res.user.email?.split("@")[0] || "User",
          email: res.user.email || "",
          inviteCode: generatedInvite,
          referredBy: referralBy,
          referralRewardSent: false,
          createdAt: new Date().toISOString(),
        };

        await set(userRef, newUserData);
        onLoginSuccess({
          uid: res.user.uid,
          ...newUserData,
          devices: {},
        });
      } else {
        const userData = userSnap.val();
        onLoginSuccess({
          uid: res.user.uid,
          email: res.user.email || "",
          name: userData.name || res.user.displayName || "User",
          isAdmin: userData.isAdmin || false,
          phone: userData.phone,
          inviteCode: userData.inviteCode,
          profilePicture: userData.profilePicture,
          devices: userData.devices || {},
        });
      }
      onNavigate("home");
    } catch (err: any) {
      setError(err.message || "Google Sign-In failed");
    }
  };

  return (
    <div
      className="flex flex-col relative min-h-screen pt-10 px-5"
      style={{
        backgroundImage: "radial-gradient(circle at 50% 0%, rgba(204,255,51,0.15) 0%, rgba(10,11,9,1) 55%)",
      }}
    >
      <header className="flex justify-between items-center mb-10">
        <button
          onClick={() => onNavigate("splash")}
          className="w-10 h-10 rounded-full bg-white/5 flex items-center justify-center border border-white/10"
        >
          <ChevronLeft size={18} />
        </button>
        <span className="font-space font-black text-xl tracking-tighter text-[#cf3]">
          Edutech
        </span>
        <div className="w-10" />
      </header>

      <main className="flex-1 flex flex-col items-center">
        <div className="w-20 h-20 rounded-full relative orb-glow mb-6 flex items-center justify-center bg-gradient-to-br from-[#cf3]/20 to-transparent p-1 border border-white/10">
          <div className="w-full h-full rounded-full bg-gradient-to-br from-[#8AAB30] to-[#1A2600] flex items-center justify-center">
            <Mail className="text-white/90" size={28} />
          </div>
        </div>

        <h1 className="text-2xl font-bold mb-1.5 tracking-tight">Welcome Back!</h1>
        <p className="text-gray-400 text-center text-sm mb-8">
          Sign in to continue your learning journey.
        </p>

        {error && (
          <div className="w-full p-3 mb-4 rounded-xl bg-red-500/10 border border-red-500/20 text-red-500 text-xs text-center">
            {error}
          </div>
        )}

        <form onSubmit={handleSubmit} className="w-full space-y-4">
          <div className="grid gap-1.5">
            <label className="text-sm font-medium text-gray-200">Email address</label>
            <input
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className="bg-white rounded-xl px-4 py-3 text-black font-medium focus:ring-2 focus:ring-[#cf3] outline-none"
              placeholder="example@gmail.com"
              required
            />
          </div>

          <div className="grid gap-1.5">
            <label className="text-sm font-medium text-gray-200">Password</label>
            <div className="relative">
              <input
                type={showPassword ? "text" : "password"}
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="bg-white rounded-xl px-4 py-3 text-black font-medium w-full focus:ring-2 focus:ring-[#cf3] outline-none"
                placeholder="Enter password"
                required
              />
              <button
                type="button"
                onClick={() => setShowPassword(!showPassword)}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-500"
              >
                {showPassword ? <EyeOff size={20} /> : <Eye size={20} />}
              </button>
            </div>
          </div>

          <button
            type="submit"
            disabled={loading}
            className="w-full bg-[#cf3] text-black font-semibold rounded-full py-4 flex items-center justify-center gap-2 hover:bg-[#b8e62e] transition"
          >
            {loading ? (
              "Signing In..."
            ) : (
              <>
                Sign In <ArrowRight size={18} />
              </>
            )}
          </button>
        </form>

        <div className="flex items-center gap-4 my-8 w-full">
          <div className="h-px bg-white/10 flex-1" />
          <span className="text-gray-500 text-sm font-medium">Or</span>
          <div className="h-px bg-white/10 flex-1" />
        </div>

        <button
          onClick={handleGoogleLogin}
          className="w-full border border-white/10 rounded-full py-3 flex items-center justify-center gap-3 hover:bg-white/5 transition mb-6"
        >
          <svg width="18" height="18" viewBox="0 0 24 24">
            <path
              d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"
              fill="#4285F4"
            />
            <path
              d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"
              fill="#34A853"
            />
            <path
              d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l3.66-2.84z"
              fill="#FBBC05"
            />
            <path
              d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84C6.71 7.31 9.14 5.38 12 5.38z"
              fill="#EA4335"
            />
          </svg>
          Continue with Google
        </button>

        <p className="text-sm text-gray-400">
          Don't have an account?{" "}
          <button
            onClick={() => onNavigate("register")}
            className="text-[#cf3] font-semibold ml-1"
          >
            Sign up
          </button>
        </p>
      </main>
    </div>
  );
}
