import { useEffect, useState, ChangeEvent } from "react";
import { User, Wallet } from "../types";
import { ArrowLeft, Gift, Plus, History, ArrowDownLeft, ArrowUpRight, Copy, Check, UploadCloud } from "lucide-react";
import { ref, get, push, set } from "firebase/database";
import { db } from "../firebase";
import { defaultQr } from "../data";

interface WalletPageProps {
  user: User;
  onNavigate: (view: string) => void;
}

export default function WalletPage({ user, onNavigate }: WalletPageProps) {
  const [wallet, setWallet] = useState<Wallet | null>(null);
  const [showAddFunds, setShowAddFunds] = useState(false);
  const [amount, setAmount] = useState<number | "">("");
  const [utr, setUtr] = useState("");
  const [screenshot, setScreenshot] = useState<string | null>(null);
  const [screenshotName, setScreenshotName] = useState("");
  const [copied, setCopied] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [paymentConfig, setPaymentConfig] = useState({
    upiId: defaultQr.upiId,
    qrDataUrl: defaultQr.qrDataUrl,
    payeeName: defaultQr.payeeName,
  });

  useEffect(() => {
    const payRef = ref(db, "settings/payment");
    get(payRef).then((snap) => {
      if (snap.exists()) {
        setPaymentConfig((prev) => ({ ...prev, ...snap.val() }));
      }
    });
  }, []);

  useEffect(() => {
    const walletRef = ref(db, `users/${user.uid}/wallet`);
    get(walletRef).then((snap) => {
      if (snap.exists()) {
        setWallet(snap.val());
      } else {
        setWallet({ balance: 0, history: [] });
      }
    });
  }, [user.uid]);

  const history = wallet?.history || [];

  const handleCopyUpi = () => {
    navigator.clipboard.writeText(paymentConfig.upiId);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const compressImage = (file: File, maxWidth = 300): Promise<string> =>
    new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = (e) => {
        const img = new Image();
        img.onload = () => {
          const canvas = document.createElement("canvas");
          let width = img.width;
          let height = img.height;
          if (width > maxWidth) {
            height = Math.round((height * maxWidth) / width);
            width = maxWidth;
          }
          canvas.width = width;
          canvas.height = height;
          const ctx = canvas.getContext("2d");
          if (!ctx) {
            resolve(e.target?.result as string);
            return;
          }
          ctx.drawImage(img, 0, 0, width, height);
          resolve(canvas.toDataURL("image/jpeg", 0.5));
        };
        img.onerror = () => {
          resolve(e.target?.result as string);
        };
        img.src = e.target?.result as string;
      };
      reader.onerror = () => reject("File read error");
      reader.readAsDataURL(file);
    });

  const handleScreenshotChange = async (e: ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      if (file.size > 5 * 1024 * 1024) {
        alert("File size too large (max 5MB)");
        return;
      }
      setScreenshotName("Uploading...");
      try {
        const compressed = await compressImage(file, 300);
        setScreenshot(compressed);
        setScreenshotName(file.name);
      } catch (err) {
        alert("Failed to process image: " + String(err));
        setScreenshotName("");
      }
      e.target.value = "";
    }
  };

  const handleAddFundsSubmit = async () => {
    if (!amount || amount < 10) {
      return alert("Minimum amount is ₹10");
    }
    if (!utr || utr.trim().length < 10) {
      return alert("Enter a valid UTR");
    }
    if (!screenshot) {
      return alert("Upload a screenshot");
    }

    setSubmitting(true);
    try {
      const submissionsRef = ref(db, "paymentSubmissions");
      const newSubRef = push(submissionsRef);
      await set(newSubRef, {
        id: newSubRef.key,
        batchId: "WALLET_TOPUP",
        batchTitle: "Wallet Top-up",
        amount: Number(amount),
        utr: utr.trim(),
        upiId: paymentConfig.upiId,
        screenshot,
        userUid: user.uid,
        userName: user.name,
        userEmail: user.email,
        status: "pending",
        createdAt: new Date().toISOString(),
      });
      alert("Top-up request submitted! Admin will verify and add funds to your wallet.");
      setShowAddFunds(false);
      setAmount("");
      setUtr("");
      setScreenshot(null);
      setScreenshotName("");
    } catch (err: any) {
      alert("Failed to submit top-up: " + err.message);
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="flex flex-col min-h-screen bg-app-bg">
      <header className="fixed top-0 left-0 right-0 z-50 bg-black/70 backdrop-blur-xl border-b border-brand-accent/30 flex items-center px-6 py-4 max-w-[460px] mx-auto">
        <button
          onClick={() => onNavigate("home")}
          className="w-10 h-10 rounded-full border border-white/10 bg-white/5 flex items-center justify-center mr-3 hover:bg-white/10 transition"
        >
          <ArrowLeft size={20} className="text-white/80" />
        </button>
        <span className="font-space font-black text-xl tracking-tighter text-brand-accent">Wallet</span>
      </header>

      <main className="pt-24 px-5 pb-10">
        <section
          className="rounded-3xl p-6 mb-6 relative overflow-hidden border border-brand-accent/40"
          style={{
            background:
              "radial-gradient(circle at top right, rgba(204,255,51,0.25), transparent 60%), linear-gradient(135deg, rgba(204,255,51,0.15), rgba(0,0,0,0.6))",
          }}
        >
          <div className="absolute -top-12 -right-10 w-44 h-44 rounded-full bg-brand-accent/20 blur-3xl" />
          <div className="relative">
            <p className="font-mono text-[10px] uppercase tracking-widest text-brand-accent mb-2">Available Balance</p>
            <p className="font-space font-bold text-5xl text-white">₹{wallet?.balance || 0}</p>
            <p className="text-white/50 text-sm mt-3 leading-relaxed">
              Earn rewards by referring friends to our batches. Use balance for discounts.
            </p>
            <div className="flex gap-3 mt-6">
              <button
                onClick={() => onNavigate("refer")}
                className="flex-1 flex items-center justify-center gap-2 px-5 py-2.5 rounded-full bg-brand-accent/20 border border-brand-accent/40 text-brand-accent font-semibold hover:bg-brand-accent/30 transition shadow-lg"
              >
                <Gift size={18} /> Refer & Earn
              </button>
              <button
                onClick={() => setShowAddFunds(!showAddFunds)}
                className="flex-1 flex items-center justify-center gap-2 px-5 py-2.5 rounded-full bg-brand-accent text-black font-semibold hover:bg-[#b8e62e] transition shadow-lg"
              >
                <Plus size={18} /> Add Funds
              </button>
            </div>
          </div>
        </section>

        {showAddFunds && (
          <section className="glass-card rounded-2xl p-5 mb-6 border border-brand-accent/20 border-t-4 border-t-brand-accent">
            <h2 className="font-space font-bold text-lg mb-4 text-white">Add Funds</h2>
            <div className="space-y-4">
              <div className="flex flex-col gap-1.5">
                <label className="text-xs font-mono uppercase tracking-widest text-white/50">Amount (₹)</label>
                <input
                  type="number"
                  value={amount}
                  onChange={(e) => setAmount(Number(e.target.value) || "")}
                  placeholder="e.g. 500"
                  className="bg-white/5 border border-white/10 outline-none rounded-xl px-4 py-3 text-white focus:border-brand-accent w-full"
                />
              </div>

              <div className="bg-black/40 rounded-xl p-4 border border-white/5 space-y-3 flex flex-col items-center">
                <p className="text-xs text-brand-accent font-medium uppercase font-mono tracking-wider self-start">
                  Pay using UPI
                </p>
                <div className="bg-white p-3 rounded-xl shadow-[0_0_20px_rgba(204,255,51,0.05)] w-fit mx-auto mb-2">
                  <img
                    src={
                      paymentConfig.qrDataUrl ||
                      `https://api.qrserver.com/v1/create-qr-code/?size=200x200&data=${encodeURIComponent(
                        `upi://pay?pa=${paymentConfig.upiId}&pn=${encodeURIComponent(
                          paymentConfig.payeeName
                        )}${amount ? `&am=${amount}` : ""}&cu=INR`
                      )}`
                    }
                    alt="QR Code"
                    className="w-32 h-32 object-contain"
                  />
                </div>
                <div className="flex items-center justify-between bg-white/5 p-3 rounded-lg border border-white/10 w-full">
                  <span className="font-space font-medium text-white tracking-wide">{paymentConfig.upiId}</span>
                  <button
                    onClick={handleCopyUpi}
                    className="p-2 bg-brand-accent/20 rounded-md text-brand-accent hover:bg-brand-accent/40 transition"
                  >
                    {copied ? <Check size={16} className="text-green-500" /> : <Copy size={16} />}
                  </button>
                </div>
              </div>

              <div className="flex flex-col gap-1.5">
                <label className="text-xs font-mono uppercase tracking-widest text-white/50">12-Digit UTR Number</label>
                <input
                  type="number"
                  value={utr}
                  onChange={(e) => setUtr(e.target.value)}
                  placeholder="e.g. 301928374650"
                  className="bg-white/5 border border-white/10 outline-none rounded-xl px-4 py-3 text-white focus:border-brand-accent w-full"
                />
              </div>

              <label className="glass-card rounded-2xl p-6 border-dashed border-white/20 flex flex-col items-center justify-center gap-3 text-center cursor-pointer transition-all relative overflow-hidden hover:bg-white/5">
                <input
                  type="file"
                  className="absolute inset-0 w-full h-full opacity-0 cursor-pointer z-10"
                  onChange={handleScreenshotChange}
                  accept="image/*"
                />
                <div className="bg-white/5 rounded-full p-4 relative z-0">
                  <UploadCloud size={32} className={screenshot ? "text-[#cf3]" : "text-white/40"} />
                </div>
                <p className="text-sm font-medium">{screenshotName || "Upload payment screenshot"}</p>
                <p className="text-[10px] text-white/40 font-mono">JPG, PNG (Auto-compressed)</p>
              </label>

              <button
                onClick={handleAddFundsSubmit}
                disabled={submitting}
                className="w-full mt-2 bg-brand-accent text-black font-bold py-3.5 rounded-full hover:bg-[#b8e62e] transition shadow-lg flex justify-center items-center gap-2"
              >
                {submitting ? "Submitting..." : "Submit Request"}
              </button>
            </div>
          </section>
        )}

        <section className="glass-card rounded-2xl p-5">
          <div className="flex items-center gap-3 mb-6">
            <div className="w-10 h-10 rounded-xl bg-white/5 flex items-center justify-center text-brand-accent">
              <History size={20} />
            </div>
            <h2 className="font-space text-lg font-semibold">Transactions</h2>
          </div>

          {history.length > 0 ? (
            <div className="space-y-4">
              {history
                .slice()
                .reverse()
                .map((item, idx) => {
                  const isAdd = item.amount > 0;
                  return (
                    <div key={idx} className="flex items-center gap-4 bg-white/5 rounded-2xl p-4 border border-white/5">
                      <div
                        className={`w-12 h-12 rounded-xl flex items-center justify-center shrink-0 ${
                          isAdd ? "bg-green-500/20 text-green-400" : "bg-red-500/20 text-red-400"
                        }`}
                      >
                        {isAdd ? <ArrowDownLeft size={24} /> : <ArrowUpRight size={24} />}
                      </div>
                      <div className="flex-1 min-w-0">
                        <p className="font-bold text-sm truncate text-white">{item.reason}</p>
                        <p className="text-xs text-white/50 font-mono mt-1">
                          {new Date(item.date).toLocaleDateString()} •{" "}
                          {new Date(item.date).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}
                        </p>
                      </div>
                      <div className="shrink-0 text-right">
                        <p className={`font-space font-bold text-lg ${isAdd ? "text-green-400" : "text-white"}`}>
                          {isAdd ? "+" : "-"}₹{Math.abs(item.amount)}
                        </p>
                      </div>
                    </div>
                  );
                })}
            </div>
          ) : (
            <div className="flex flex-col items-center justify-center py-10 opacity-30 gap-3">
              <History size={32} />
              <p className="text-sm font-mono uppercase tracking-widest text-center">No history yet</p>
            </div>
          )}
        </section>
      </main>
    </div>
  );
}
