import { Device, User } from "../types";
import { ChevronLeft, Shield, Smartphone, Monitor, Clock, Check, X, LogOut } from "lucide-react";
import { ref, update } from "firebase/database";
import { db } from "../firebase";
import { getDeviceId } from "../utils"; // We'll create this to generate or retrieve a unique device ID

interface SecurityPageProps {
  user: User;
  onNavigate: (view: string) => void;
}

export default function SecurityPage({ user, onNavigate }: SecurityPageProps) {
  const currentDeviceId = getDeviceId();
  const devicesMap = user.devices || {};
  const devicesList = Object.values(devicesMap).sort(
    (a, b) => new Date(b.lastLogin).getTime() - new Date(a.lastLogin).getTime()
  );

  const handleApprove = async (deviceId: string) => {
    if (confirm("Allow this device to log in to your account?")) {
      await update(ref(db, `users/${user.uid}/devices/${deviceId}`), { status: "approved" });
    }
  };

  const handleRevoke = async (deviceId: string) => {
    if (confirm("Revoke access for this device? It will be logged out immediately.")) {
      await update(ref(db, `users/${user.uid}/devices/${deviceId}`), { status: "revoked" });
    }
  };

  const handleLogoutAllOther = async () => {
    if (!confirm("Log out from all other devices? This will revoke their access.")) return;
    const updates: Record<string, any> = {};
    Object.keys(devicesMap).forEach((id) => {
      if (id !== currentDeviceId) {
        updates[`${id}/status`] = "revoked";
      }
    });

    if (Object.keys(updates).length > 0) {
      await update(ref(db, `users/${user.uid}/devices`), updates);
      alert("All other devices have been logged out.");
    } else {
      alert("No other devices found.");
    }
  };

  const getDeviceIcon = (ua?: string) => {
    const cleanUa = (ua || "").toLowerCase();
    if (cleanUa.includes("mobile") || cleanUa.includes("android") || cleanUa.includes("iphone")) {
      return <Smartphone size={24} className="text-white/60" />;
    }
    return <Monitor size={24} className="text-white/60" />;
  };

  return (
    <div className="flex flex-col h-screen bg-[#09090b] text-white">
      <header className="px-6 py-4 flex items-center justify-between border-b border-white/10 sticky top-0 bg-[#09090b]/80 backdrop-blur-md z-10 shrink-0">
        <div className="flex items-center gap-3">
          <button onClick={() => onNavigate("home")} className="p-2 -ml-2 rounded-full hover:bg-white/10 transition">
            <ChevronLeft size={24} />
          </button>
          <h1 className="text-xl font-bold tracking-tight">Security</h1>
        </div>
      </header>

      <div className="flex-1 overflow-y-auto px-6 py-6 pb-24">
        <div className="flex items-center gap-3 mb-6 bg-brand-accent/10 p-4 rounded-2xl border border-brand-accent/20">
          <Shield className="text-brand-accent" size={32} />
          <div>
            <h2 className="font-bold text-lg leading-tight">Device Management</h2>
            <p className="text-xs text-brand-accent/80">Monitor and manage the devices connected to your account.</p>
          </div>
        </div>

        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="font-bold text-white/80">Active Sessions</h3>
            <button
              onClick={handleLogoutAllOther}
              className="text-xs text-red-400 bg-red-400/10 px-3 py-1.5 rounded-lg border border-red-400/20 hover:bg-red-400/20 transition flex items-center gap-1.5"
            >
              <LogOut size={14} /> Log out all other
            </button>
          </div>

          <div className="space-y-3">
            {devicesList.length === 0 && <p className="text-white/40 text-sm italic">No devices tracked yet.</p>}
            {devicesList.map((device) => {
              const isCurrent = device.deviceId === currentDeviceId;
              return (
                <div
                  key={device.deviceId}
                  className="bg-white/5 border border-white/10 p-4 rounded-2xl flex flex-col gap-3 relative overflow-hidden"
                >
                  {isCurrent && (
                    <div className="absolute top-0 right-0 bg-brand-accent text-black text-[10px] font-bold px-3 py-1 rounded-bl-lg">
                      CURRENT DEVICE
                    </div>
                  )}

                  <div className="flex items-start gap-3">
                    <div className="p-3 bg-white/5 rounded-xl border border-white/10 shrink-0">
                      {getDeviceIcon(device.userAgent)}
                    </div>
                    <div className="min-w-0 flex-1">
                      <p className="font-semibold text-sm truncate">
                        {(device.userAgent || "Unknown").split(")")[0] +
                          ((device.userAgent || "").includes(")") ? ")" : "")}
                      </p>
                      <div className="flex items-center gap-4 mt-1">
                        <p className="text-[10px] text-white/40 flex items-center gap-1 font-mono">
                          <Clock size={10} />
                          {new Date(device.lastLogin).toLocaleString(void 0, {
                            month: "short",
                            day: "numeric",
                            hour: "2-digit",
                            minute: "2-digit",
                          })}
                        </p>
                        <div className="text-[10px] flex items-center gap-1">
                          {device.status === "approved" && (
                            <span className="text-green-400 flex items-center gap-1">
                              <Check size={10} /> Approved
                            </span>
                          )}
                          {device.status === "pending" && (
                            <span className="text-yellow-400 flex items-center gap-1">
                              <Clock size={10} /> Pending
                            </span>
                          )}
                          {device.status === "revoked" && (
                            <span className="text-red-400 flex items-center gap-1">
                              <X size={10} /> Revoked
                            </span>
                          )}
                        </div>
                      </div>
                    </div>
                  </div>

                  {!isCurrent && (
                    <div className="flex items-center gap-2 mt-2 pt-3 border-t border-white/10">
                      {device.status !== "approved" && (
                        <button
                          onClick={() => handleApprove(device.deviceId)}
                          className="flex-1 bg-green-500/20 text-green-500 hover:bg-green-500/30 font-bold py-2 rounded-xl text-xs transition"
                        >
                          Approve
                        </button>
                      )}
                      {device.status !== "revoked" && (
                        <button
                          onClick={() => handleRevoke(device.deviceId)}
                          className="flex-1 bg-red-500/20 text-red-500 hover:bg-red-500/30 font-bold py-2 rounded-xl text-xs transition"
                        >
                          Revoke Access
                        </button>
                      )}
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </div>
  );
}
