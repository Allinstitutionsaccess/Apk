import { User } from "../types";
import { User as UserIcon, Shield, BookOpen, Gift, Headphones, LogOut, X } from "lucide-react";
import { motion, AnimatePresence } from "motion/react";
import { auth } from "../firebase";
import { signOut } from "firebase/auth";

interface SidebarMenuProps {
  isOpen: boolean;
  onClose: () => void;
  onNavigate: (view: string) => void;
  user: User;
}

export default function SidebarMenu({ isOpen, onClose, onNavigate, user }: SidebarMenuProps) {
  const menuItems = [
    { icon: UserIcon, label: "Profile", action: () => { onNavigate("profile"); onClose(); } },
    { icon: Shield, label: "Security", action: () => { onNavigate("security"); onClose(); } },
    { icon: BookOpen, label: "My Courses", action: () => { onNavigate("mycourses"); onClose(); } },
    { icon: Gift, label: "Refer & Earn", action: () => { onNavigate("refer"); onClose(); } },
    {
      icon: Headphones,
      label: "Help & Support",
      action: () => {
        alert("Contact support at admin@edutech.com");
        onClose();
      },
    },
    {
      icon: LogOut,
      label: "Logout",
      action: async () => {
        try {
          await signOut(auth);
          onNavigate("login");
          onClose();
        } catch (err) {
          console.error("Logout failed:", err);
        }
      },
      className: "text-red-500 hover:bg-red-500/10",
    },
  ];

  return (
    <AnimatePresence>
      {isOpen && (
        <>
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/60 backdrop-blur-sm z-[100] overflow-hidden"
            onClick={onClose}
          />
          <motion.div
            initial={{ x: "-100%" }}
            animate={{ x: 0 }}
            exit={{ x: "-100%" }}
            transition={{ type: "spring", damping: 25, stiffness: 200 }}
            className="fixed top-0 bottom-0 left-0 w-[280px] bg-[#09090b] border-r border-white/10 z-[101] flex flex-col"
          >
            <div className="p-6 border-b border-white/10 flex justify-between items-center bg-white/5">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-full bg-[#cf3]/20 flex items-center justify-center border border-[#cf3]/50 text-[#cf3] font-bold overflow-hidden">
                  {user?.profilePicture ? (
                    <img src={user.profilePicture} alt={user.name} className="w-full h-full object-cover" />
                  ) : (
                    user?.name?.[0]?.toUpperCase() || "U"
                  )}
                </div>
                <div>
                  <p className="font-bold text-white leading-tight">{user?.name || "User"}</p>
                  <p className="text-xs text-white/50">{user?.email}</p>
                </div>
              </div>
              <button onClick={onClose} className="text-white/50 hover:text-white transition">
                <X size={20} />
              </button>
            </div>
            <div className="flex-1 overflow-y-auto py-4">
              <div className="flex flex-col px-4 gap-2">
                {menuItems.map((item, idx) => (
                  <button
                    key={idx}
                    onClick={item.action}
                    className={`flex items-center gap-4 px-4 py-3 rounded-xl transition hover:bg-white/5 ${
                      item.className || "text-white"
                    }`}
                  >
                    <item.icon size={20} className={item.className ? "" : "text-[#cf3]"} />
                    <span className="font-medium">{item.label}</span>
                  </button>
                ))}
              </div>
            </div>
            <div className="p-6 border-t border-white/10">
              <div className="text-xs text-white/30 text-center font-mono">
                Edutech App v1.0.0
              </div>
            </div>
          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
}
