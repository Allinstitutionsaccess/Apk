import { useEffect, useState } from "react";
import { Batch } from "../types";
import { GraduationCap, Award } from "lucide-react";
import { ref, get, set } from "firebase/database";
import { db } from "../firebase";

interface RecommendPanelProps {
  batches: Batch[];
}

export default function RecommendPanel({ batches }: RecommendPanelProps) {
  const [recIds, setRecIds] = useState<string[]>([]);

  useEffect(() => {
    const recRef = ref(db, "settings/recommended");
    get(recRef).then((snap) => {
      if (snap.exists()) {
        const val = snap.val();
        setRecIds(Array.isArray(val) ? val : Object.values(val));
      }
    });
  }, []);

  const toggleRec = async (id: string) => {
    let updated;
    if (recIds.includes(id)) {
      updated = recIds.filter((x) => x !== id);
    } else {
      updated = [...recIds, id];
    }
    setRecIds(updated);
    await set(ref(db, "settings/recommended"), updated);
  };

  return (
    <div className="space-y-6 animate-in fade-in slide-in-from-bottom-4 duration-500">
      <section className="glass-card rounded-2xl p-6 border border-brand-accent/20">
        <div className="flex items-center gap-3 mb-2">
          <GraduationCap size={22} className="text-brand-accent" />
          <h2 className="text-xl font-bold">Recommend Batches</h2>
        </div>
        <p className="text-white/40 text-sm mb-6">
          Toggle batches to show in 'Recommended for You' on user home screen.
        </p>

        <div className="flex flex-col gap-3">
          {batches.map((batch) => (
            <div
              key={batch.id}
              className="flex items-center justify-between p-4 rounded-xl bg-white/5 border border-white/10 hover:border-brand-accent/30 transition"
            >
              <div className="flex items-center gap-3 min-w-0">
                {batch.thumbnail && (
                  <img
                    src={batch.thumbnail}
                    className="w-12 h-12 rounded-lg object-cover border border-white/10 shrink-0"
                    alt={batch.title}
                  />
                )}
                <div className="min-w-0">
                  <p className="font-bold text-sm truncate">{batch.title}</p>
                  <p className="text-xs text-white/40 font-mono mt-0.5">
                    ₹{(batch.discountPrice || 0).toLocaleString()} • {batch.tag}
                  </p>
                </div>
              </div>

              <button
                onClick={() => toggleRec(batch.id)}
                className={
                  recIds.includes(batch.id)
                    ? "px-4 py-2 rounded-xl bg-brand-accent text-black text-xs font-bold transition"
                    : "px-4 py-2 rounded-xl bg-white/10 text-white/50 text-xs font-bold hover:bg-white/20 transition"
                }
              >
                {recIds.includes(batch.id) ? "✓ Recommended" : "+ Recommend"}
              </button>
            </div>
          ))}
        </div>
      </section>

      {recIds.length > 0 && (
        <div className="mt-4 p-3 rounded-xl bg-brand-accent/10 border border-brand-accent/20">
          <p className="text-brand-accent text-xs font-mono">
            {recIds.length} batch(es) currently recommended to users
          </p>
        </div>
      )}
    </div>
  );
}
