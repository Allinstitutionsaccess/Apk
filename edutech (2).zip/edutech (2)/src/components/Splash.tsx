import { useEffect, useState, useRef } from "react";
import { GraduationCap } from "lucide-react";
import { motion } from "motion/react";

interface SplashProps {
  onComplete?: () => void;
  showButton?: boolean;
}

export default function Splash({ onComplete, showButton = true }: SplashProps) {
  const [loadingText, setLoadingText] = useState("Loading...");
  const onCompleteRef = useRef(onComplete);

  // Keep the ref updated with the latest callback
  useEffect(() => {
    onCompleteRef.current = onComplete;
  }, [onComplete]);

  useEffect(() => {
    const texts = ["Loading...", "Securing Connection...", "Welcome to Edutech!"];
    let i = 0;
    const interval = setInterval(() => {
      i++;
      if (i < texts.length) {
        setLoadingText(texts[i]);
      }
    }, 800);

    let timer: NodeJS.Timeout | null = null;
    if (showButton) {
      timer = setTimeout(() => {
        if (onCompleteRef.current) {
          onCompleteRef.current();
        }
      }, 2500);
    }

    return () => {
      clearInterval(interval);
      if (timer) clearTimeout(timer);
    };
  }, [showButton]);

  return (
    <div
      className="flex flex-col justify-center items-center h-screen w-full relative overflow-hidden bg-black"
      onClick={() => {
        if (showButton && onComplete) {
          onComplete();
        }
      }}
    >
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,_rgba(204,255,51,0.10),_rgba(0,0,0,0.95)_60%,_#000_100%)] z-0 pointer-events-none" />
      <main className="flex flex-col items-center justify-center w-full h-full relative z-10">
        <motion.div
          initial={{ scale: 0.8, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          transition={{ duration: 0.8, ease: "easeOut" }}
          className="relative w-44 h-44 mb-8 flex justify-center items-center"
        >
          <div className="absolute inset-0 rounded-full bg-[#cf3] opacity-20 blur-2xl animate-pulse" />
          <div className="relative z-10 w-36 h-36 rounded-full bg-gradient-to-br from-[#CCFF33] via-[#8AAB30] to-[#1A2600] flex items-center justify-center shadow-[0_0_60px_rgba(204,255,51,0.6)]">
            <GraduationCap size={56} className="text-black" />
          </div>
        </motion.div>
        <motion.h1
          initial={{ y: 20, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ delay: 0.3, duration: 0.6 }}
          className="text-5xl font-space font-black tracking-wider text-[#cf3] text-glow"
        >
          Edutech
        </motion.h1>
        <motion.p
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 1, duration: 1 }}
          className="mt-4 text-gray-400 animate-pulse text-sm font-mono"
        >
          {loadingText}
        </motion.p>
        {showButton && (
          <motion.button
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 1.5 }}
            className="mt-10 px-8 py-3 rounded-full bg-[#cf3] text-black font-semibold text-sm hover:bg-[#b8e62e] transition active:scale-[0.98] shadow-[0_0_20px_rgba(204,255,51,0.4)]"
            onClick={(e) => {
              e.stopPropagation();
              onComplete && onComplete();
            }}
          >
            Get Started
          </motion.button>
        )}
      </main>
    </div>
  );
}
