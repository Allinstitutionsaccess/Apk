import { Submission, Batch, User } from "../types";
import { Menu, BookOpen, ExternalLink, GraduationCap } from "lucide-react";
import BottomNav from "./BottomNav";

interface MyCoursesProps {
  submissions: Submission[];
  batches: Batch[];
  user: User;
  onNavigate: (view: string) => void;
}

export default function MyCourses({ submissions, batches, user, onNavigate }: MyCoursesProps) {
  const approvedList = submissions.filter((sub) => sub.status === "approved" && sub.userUid === user.uid);
  const triggerMenu = () => window.dispatchEvent(new CustomEvent("openMenu"));

  return (
    <div className="flex flex-col min-h-screen pb-32">
      <header className="fixed top-0 left-0 right-0 z-50 bg-black/60 backdrop-blur-lg border-b border-white/10 flex justify-between items-center px-6 py-4 max-w-[460px] mx-auto">
        <div className="flex items-center gap-3">
          <button className="text-[#cf3] cursor-pointer" onClick={triggerMenu}>
            <Menu size={24} />
          </button>
          <span className="font-space font-black text-2xl tracking-tighter text-[#cf3]">
            Edutech
          </span>
        </div>
      </header>

      <main className="pt-28 px-5">
        <section className="mb-6">
          <div className="flex items-center gap-2 mb-1">
            <GraduationCap size={20} className="text-[#cf3]" />
            <span className="font-mono text-[#cf3] text-xs uppercase tracking-widest">
              My Learning
            </span>
          </div>
          <h1 className="font-space text-3xl font-bold tracking-tight">Active Batches</h1>
          <p className="text-white/40 text-sm mt-1">Your verified enrollments appear here.</p>
        </section>

        <div className="flex flex-col gap-4">
          {approvedList.length === 0 ? (
            <div className="flex flex-col items-center justify-center py-20 text-center gap-4">
              <BookOpen size={48} className="text-white/10" />
              <p className="text-white/30 text-sm">No courses enrolled yet.</p>
              <button
                onClick={() => onNavigate("institute")}
                className="px-6 py-2 bg-[#cf3] text-black font-bold rounded-full text-sm"
              >
                Enroll Now
              </button>
            </div>
          ) : (
            approvedList.map((sub) => {
              const matchedBatch = batches.find((b) => b.id === sub.batchId);
              const brandColor = matchedBatch?.color || "#CCFF33";

              return (
                <div
                  key={sub.id}
                  className="glass-card rounded-2xl overflow-hidden group border border-white/10 hover:border-[#cf3]/40 transition-all"
                >
                  <div className="h-1.5 w-full" style={{ backgroundColor: brandColor }} />
                  <div className="p-5">
                    <div className="flex items-start gap-4">
                      <div
                        className="w-14 h-14 rounded-xl shrink-0 flex items-center justify-center border border-white/10 overflow-hidden"
                        style={{ background: `linear-gradient(135deg, ${brandColor}22, #000)` }}
                      >
                        {matchedBatch?.thumbnail ? (
                          <img
                            src={matchedBatch.thumbnail}
                            alt={sub.batchTitle}
                            className="w-full h-full object-cover"
                          />
                        ) : (
                          <GraduationCap size={28} style={{ color: brandColor }} />
                        )}
                      </div>
                      <div className="flex-1 min-w-0">
                        <p className="font-bold text-base truncate">{sub.batchTitle}</p>
                        <p className="font-mono text-[10px] text-white/40 uppercase tracking-widest mt-1">
                          {matchedBatch?.tag || "Course"}
                        </p>
                        <div className="mt-2 inline-flex items-center gap-1.5 px-2 py-0.5 rounded-full text-[10px] bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
                          Verified Enrollment
                        </div>
                      </div>
                    </div>

                    <div className="mt-5">
                      {sub.accessLink ? (
                        <a
                          href={sub.accessLink}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="w-full flex items-center justify-center gap-2 py-3.5 rounded-xl font-space font-bold text-sm text-black transition active:scale-[0.98]"
                          style={{ backgroundColor: brandColor }}
                        >
                          Access Learning Portal <ExternalLink size={18} />
                        </a>
                      ) : (
                        <div className="w-full py-3.5 rounded-xl bg-white/5 border border-white/10 text-white/30 text-center text-sm">
                          Portal Link Pending
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              );
            })
          )}
        </div>
      </main>

      <BottomNav active="mycourses" onNavigate={onNavigate} />
    </div>
  );
}
