import { LayoutGrid, School, BookOpen, Library } from "lucide-react";

interface BottomNavProps {
  active: string;
  onNavigate: (view: string) => void;
}

export default function BottomNav({ active, onNavigate }: BottomNavProps) {
  const tabs = [
    { id: "home", label: "Home", icon: LayoutGrid },
    { id: "institute", label: "Institutes", icon: School },
    { id: "mycourses", label: "Courses", icon: BookOpen },
    { id: "ebooks", label: "Ebooks", icon: Library },
  ];

  return (
    <nav className="fixed bottom-0 left-0 right-0 z-50 bg-black/80 backdrop-blur-2xl border-t border-white/10 flex justify-around items-center px-4 pb-6 pt-3 rounded-t-2xl max-w-[460px] mx-auto">
      {tabs.map((tab) => (
        <button
          key={tab.id}
          onClick={() => onNavigate(tab.id)}
          className={`flex flex-col items-center justify-center transition group ${
            active === tab.id ? "text-[#cf3]" : "text-white/40 hover:text-[#cf3]"
          }`}
        >
          <tab.icon size={24} fill={active === tab.id ? "currentColor" : "none"} />
          <span className="font-space text-[10px] font-bold uppercase tracking-tighter mt-1">
            {tab.label}
          </span>
        </button>
      ))}
    </nav>
  );
}
