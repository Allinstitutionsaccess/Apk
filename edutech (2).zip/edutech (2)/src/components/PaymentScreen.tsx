import { useEffect, useState, ChangeEvent } from "react";
import { Batch, User } from "../types";
import { ArrowLeft, Shield, Timer, Copy, Check, UploadCloud, Tag, HelpCircle, CircleCheckBig, CircleX, Clock } from "lucide-react";
import { ref, get, push, set } from "firebase/database";
import { db } from "../firebase";
import { defaultQr } from "../data";

interface PaymentScreenProps {
  batch: Batch;
  user: User;
  onNavigate: (view: string) => void;
}

export default function PaymentScreen({ batch, user, onNavigate }: PaymentScreenProps) {
  const [timeLeft, setTimeLeft] = useState(900); // 15 mins
  const [utr, setUtr] = useState("");
  const [screenshot, setScreenshot] = useState<string | null>(null);
  const [screenshotName, setScreenshotName] = useState("");
  const [confirmed, setConfirmed] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [paymentConfig, setPaymentConfig] = useState({
    upiId: defaultQr.upiId,
    qrDataUrl: defaultQr.qrDataUrl,
    payeeName: defaultQr.payeeName,
  });

  useEffect(() => {
    const payRef = ref(db, "settings/payment");
    get(payRef).then((snap) => {
      if (snap.exists()) {
        setPaymentConfig((prev) => ({ ...prev, ...snap.val() }));
      }
    });
  }, []);

  useEffect(() => {
    const interval = setInterval(() => {
      setTimeLeft((prev) => (prev > 0 ? prev - 1 : 0));
    }, 1000);
    return () => clearInterval(interval);
  }, []);

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins.toString().padStart(2, "0")}:${secs.toString().padStart(2, "0")}`;
  };

  const compressImage = (file: File, maxWidth = 400): Promise<string> =>
    new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = (e) => {
        const img = new Image();
        img.onload = () => {
          const canvas = document.createElement("canvas");
          let width = img.width;
          let height = img.height;
          if (width > maxWidth) {
            height = Math.round((height * maxWidth) / width);
            width = maxWidth;
          }
          canvas.width = width;
          canvas.height = height;
          const ctx = canvas.getContext("2d");
          if (!ctx) {
            resolve(e.target?.result as string);
            return;
          }
          ctx.drawImage(img, 0, 0, width, height);
          resolve(canvas.toDataURL("image/jpeg", 0.5));
        };
        img.onerror = () => {
          resolve(e.target?.result as string);
        };
        img.src = e.target?.result as string;
      };
      reader.onerror = () => reject("File read error");
      reader.readAsDataURL(file);
    });

  const handleScreenshotChange = async (e: ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      if (file.size > 5 * 1024 * 1024) {
        alert("File size too large (max 5MB)");
        return;
      }
      setScreenshotName("Uploading...");
      try {
        const compressed = await compressImage(file, 400);
        setScreenshot(compressed);
        setScreenshotName(file.name);
      } catch (err) {
        console.error("Failed to compress image:", err);
        alert("Failed to process image. Please try another standard image format.");
        setScreenshotName("");
      }
      e.target.value = "";
    }
  };

  const handleSubmit = async () => {
    if (!utr || utr.trim().length < 10) {
      return alert("Enter a valid 12-digit UTR");
    }
    if (!screenshot) {
      return alert("Upload a payment screenshot");
    }
    if (!confirmed) {
      return alert("Please confirm the payment");
    }

    setSubmitting(true);
    try {
      const submissionsRef = ref(db, "paymentSubmissions");
      const newSubRef = push(submissionsRef);
      await set(newSubRef, {
        id: newSubRef.key,
        batchId: batch.id,
        batchTitle: batch.title,
        amount: batch.discountPrice || batch.actualPrice,
        utr: utr.trim(),
        upiId: activeUpiId,
        screenshot,
        userUid: user.uid,
        userName: user.name,
        userEmail: user.email,
        status: "pending",
        createdAt: new Date().toISOString(),
      });
      alert("Payment submitted for verification! It will be approved shortly.");
      onNavigate("mycourses");
    } catch (err: any) {
      console.error(err);
      alert("Submission failed: " + err.message);
    } finally {
      setSubmitting(false);
    }
  };

  const targetPrice = batch.discountPrice || batch.actualPrice;
  const activeUpiId = batch.upiId || paymentConfig.upiId;
  const activeQrUrl = batch.qrDataUrl || paymentConfig.qrDataUrl;
  const upiPayLink =
    batch.upiPayLink ||
    `upi://pay?pa=${activeUpiId}&pn=${encodeURIComponent(paymentConfig.payeeName || "Merchant")}&am=${targetPrice}&cu=INR`;

  return (
    <div className="flex flex-col min-h-screen bg-app-bg">
      <header className="fixed top-0 left-0 right-0 z-50 bg-black/70 backdrop-blur-xl border-b border-white/10 flex justify-between items-center px-5 py-4 max-w-[460px] mx-auto">
        <button onClick={() => onNavigate("batch")} className="text-white/60 hover:text-brand-accent transition">
          <ArrowLeft size={24} />
        </button>
        <h1 className="font-space uppercase tracking-widest text-xs text-[#cf3] font-bold">Secure Payment</h1>
        <Shield size={20} className="text-[#cf3] opacity-80" />
      </header>

      <main className="pt-24 pb-16 px-5 flex flex-col gap-5 overflow-y-auto">
        <section className="glass-card rounded-2xl p-6 relative overflow-hidden">
          <div className="absolute inset-0 bg-gradient-to-br from-[#cf3]/5 to-transparent pointer-events-none" />
          <div className="relative z-10 flex justify-between items-center">
            <div>
              <p className="text-[10px] uppercase tracking-widest font-mono text-white/50 mb-1">{batch.tag}</p>
              <h2 className="font-space text-lg font-semibold text-white mb-3">{batch.title}</h2>
              <div className="font-space text-4xl font-semibold text-[#cf3]">
                ₹{targetPrice.toLocaleString("en-IN")}
                <span className="text-sm font-normal text-white/50">.00</span>
              </div>
            </div>
            <div className="flex flex-col items-end">
              <p className="text-[10px] font-mono text-white/50 mb-2">Securing slot</p>
              <div className="rounded-lg px-3 py-1.5 flex items-center gap-2 border border-[#cf3]/40 bg-[#cf3]/5">
                <Timer size={16} className="text-[#cf3]" />
                <span className="font-space text-xl font-bold text-[#cf3] tracking-widest">{formatTime(timeLeft)}</span>
              </div>
            </div>
          </div>
        </section>

        <section className="glass-card rounded-2xl p-6 flex flex-col items-center gap-5">
          <p className="text-[10px] font-mono uppercase tracking-widest text-white/60">Scan to Pay via UPI</p>
          <div className="bg-white p-4 rounded-xl shadow-[0_0_30px_rgba(204,255,51,0.1)]">
            <img
              src={
                activeQrUrl ||
                `https://api.qrserver.com/v1/create-qr-code/?size=240x240&data=${encodeURIComponent(upiPayLink)}`
              }
              alt="QR Code"
              className="w-40 h-40 object-contain"
            />
          </div>
          <a
            href={upiPayLink}
            className="w-full flex items-center justify-center gap-2 bg-[#cf3] text-black font-space font-bold py-3 rounded-full text-sm hover:opacity-90 transition"
          >
            Pay with UPI App
          </a>
          <div className="w-full">
            <p className="text-xs font-mono text-white/50 mb-2 text-center">UPI ID</p>
            <div className="rounded-lg flex items-center justify-between p-1 pl-4 border border-white/10 bg-white/5">
              <span className="text-sm font-mono text-[#cf3]">{activeUpiId}</span>
              <button
                onClick={() => {
                  navigator.clipboard.writeText(activeUpiId);
                  alert("UPI ID Copied");
                }}
                className="bg-white/5 p-2 rounded-md"
              >
                <Copy size={16} />
              </button>
            </div>
          </div>
        </section>

        <section className="flex flex-col gap-5">
          <div className="glass-card rounded-2xl p-6">
            <label className="text-xs font-mono uppercase tracking-widest text-white flex items-center gap-2 mb-3">
              <Tag size={16} className="text-[#cf3]" /> Transaction ID / UTR
            </label>
            <input
              className="bg-white rounded-xl px-4 py-3 w-full text-black font-mono focus:ring-2 focus:ring-[#cf3] outline-none"
              placeholder="e.g. 301928374650"
              value={utr}
              onChange={(e) => setUtr(e.target.value)}
            />
          </div>

          <label className="glass-card rounded-2xl p-6 border-dashed border-white/20 flex flex-col items-center justify-center gap-3 text-center cursor-pointer transition-all relative overflow-hidden hover:bg-white/5">
            <input
              type="file"
              className="absolute inset-0 w-full h-full opacity-0 cursor-pointer z-10"
              onChange={handleScreenshotChange}
              accept="image/*"
            />
            <div className="bg-white/5 rounded-full p-4 relative z-0">
              <UploadCloud size={32} className={screenshot ? "text-[#cf3]" : "text-white/40"} />
            </div>
            <p className="text-sm font-medium">{screenshotName || "Upload payment screenshot"}</p>
            <p className="text-[10px] text-white/40 font-mono">JPG, PNG (Auto-compressed)</p>
          </label>
        </section>

        <section className="flex flex-col gap-4 mt-2">
          <label className="flex items-start gap-3 cursor-pointer">
            <input
              type="checkbox"
              checked={confirmed}
              onChange={(e) => setConfirmed(e.target.checked)}
              className="mt-1 w-5 h-5 rounded border-white/20 bg-white/5 text-brand-accent focus:ring-brand-accent"
            />
            <p className="text-xs text-white/60 leading-relaxed">
              I confirm that I have made the payment to the correct UPI ID and the details provided above are
              accurate.
            </p>
          </label>

          <button
            disabled={submitting}
            onClick={handleSubmit}
            className="w-full bg-[#cf3] text-black font-space font-bold py-4 rounded-full shadow-lg hover:bg-[#b8e62e] transition"
          >
            {submitting ? "Submitting..." : "Submit Verification"}
          </button>
        </section>

        <footer className="mt-4 border-t border-white/10 pt-6 pb-10">
          <h3 className="text-xs font-mono uppercase tracking-widest text-white/60 mb-5 flex items-center gap-2">
            <HelpCircle size={16} /> How to pay
          </h3>
          <ol className="flex flex-col gap-4 text-sm text-white/50 relative pl-6 before:absolute before:left-[11px] before:top-2 before:bottom-2 before:w-[2px] before:bg-white/10">
            <li className="relative before:absolute before:-left-[19px] before:top-0.5 before:w-4 before:h-4 before:bg-white/10 before:rounded-full before:flex before:items-center before:justify-center before:text-[10px] before:content-['1']">
              Open any UPI app (GPay, PhonePe, Paytm).
            </li>
            <li className="relative before:absolute before:-left-[19px] before:top-0.5 before:w-4 before:h-4 before:bg-white/10 before:rounded-full before:flex before:items-center before:justify-center before:text-[10px] before:content-['2']">
              Scan the QR code or enter the UPI ID manually.
            </li>
            <li className="relative before:absolute before:-left-[19px] before:top-0.5 before:w-4 before:h-4 before:bg-white/10 before:rounded-full before:flex before:items-center before:justify-center before:text-[10px] before:content-['3']">
              Send the exact amount and copy the 12-digit UTR.
            </li>
          </ol>
        </footer>
      </main>
    </div>
  );
}
