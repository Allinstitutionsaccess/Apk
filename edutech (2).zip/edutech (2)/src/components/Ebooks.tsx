import { useState } from "react";
import { Ebook } from "../types";
import { ArrowLeft, Search, X, Library } from "lucide-react";
import BottomNav from "./BottomNav";

interface EbooksProps {
  ebooks: Ebook[];
  onNavigate: (view: string) => void;
}

export default function Ebooks({ ebooks, onNavigate }: EbooksProps) {
  const [searchTerm, setSearchTerm] = useState("");
  const [activeCategory, setActiveCategory] = useState("all");
  const [selectedBook, setSelectedBook] = useState<Ebook | null>(null);

  const list = ebooks || [];
  const categories = ["all", ...Array.from(new Set(list.map((b) => b.category).filter(Boolean)))];

  const filtered = list.filter((b) => {
    const matchesCategory = activeCategory === "all" || b.category === activeCategory;
    const term = searchTerm.trim().toLowerCase();
    const matchesSearch =
      !term ||
      (b.title || "").toLowerCase().includes(term) ||
      (b.author || "").toLowerCase().includes(term) ||
      (b.category || "").toLowerCase().includes(term);
    return matchesCategory && matchesSearch;
  });

  return (
    <div className="flex flex-col min-h-screen pb-32">
      <header className="fixed top-0 left-0 right-0 z-50 bg-black/60 backdrop-blur-lg border-b border-white/10 flex justify-between items-center px-6 py-4 max-w-[460px] mx-auto">
        <div className="flex items-center gap-3">
          <button className="text-[#cf3] cursor-pointer" onClick={() => onNavigate("home")}>
            <ArrowLeft size={24} />
          </button>
          <span className="font-space font-black text-2xl tracking-tighter text-[#cf3]">
            Edutech
          </span>
        </div>
      </header>

      <main className="pt-28 px-5">
        <section className="mb-5">
          <h1 className="font-space text-3xl font-bold tracking-tight">Ebooks</h1>
          <p className="text-white/40 text-sm mt-1">Study material & reference books.</p>
        </section>

        <div className="relative mb-4">
          <Search size={18} className="absolute left-4 top-1/2 -translate-y-1/2 text-white/30" />
          <input
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            placeholder="Search books, authors, categories..."
            className="w-full bg-white/5 border border-white/10 rounded-xl pl-11 pr-4 py-3 outline-none focus:border-[#cf3] text-sm"
          />
          {searchTerm && (
            <button
              onClick={() => setSearchTerm("")}
              className="absolute right-3 top-1/2 -translate-y-1/2 text-white/30 hover:text-white/60"
            >
              <X size={16} />
            </button>
          )}
        </div>

        <div className="flex gap-2 overflow-x-auto pb-2 mb-5 -mx-1 px-1 scrollbar-hide">
          {categories.map((c) => (
            <button
              key={c}
              onClick={() => setActiveCategory(c || "all")}
              className={`shrink-0 px-4 py-2 rounded-full text-xs font-bold uppercase tracking-wide transition border ${
                activeCategory === c
                  ? "bg-[#cf3] text-black border-[#cf3]"
                  : "bg-white/5 text-white/50 border-white/10 hover:bg-white/10"
              }`}
            >
              {c === "all" ? "All" : c}
            </button>
          ))}
        </div>

        {filtered.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-20 text-center gap-4">
            <Library size={48} className="text-white/20" />
            <p className="text-white/40 text-sm">
              {list.length === 0 ? "No ebooks available yet. Check back soon!" : "No books match your search."}
            </p>
          </div>
        ) : (
          <div className="grid grid-cols-2 gap-4">
            {filtered.map((b) => (
              <div
                key={b.id}
                className="glass-card rounded-2xl overflow-hidden border border-white/10 hover:border-[#cf3]/40 transition cursor-pointer group"
                onClick={() => setSelectedBook(b)}
              >
                <div className="h-36 w-full overflow-hidden relative bg-white/5">
                  {b.thumbnail ? (
                    <img src={b.thumbnail} alt={b.title} className="w-full h-full object-cover" />
                  ) : (
                    <div className="w-full h-full flex items-center justify-center">
                      <Library size={28} className="text-white/15" />
                    </div>
                  )}
                  <span
                    className={`absolute top-2 right-2 text-[10px] font-bold px-2 py-1 rounded-full ${
                      b.price > 0 ? "bg-black/70 text-[#cf3]" : "bg-[#cf3] text-black"
                    }`}
                  >
                    {b.price > 0 ? `₹${b.price}` : "FREE"}
                  </span>
                </div>
                <div className="p-3">
                  <p className="font-space font-bold text-sm truncate text-white group-hover:text-[#cf3] transition">
                    {b.title}
                  </p>
                  {b.author && <p className="text-white/40 text-xs truncate mt-0.5">{b.author}</p>}
                  {b.category && (
                    <p className="font-mono text-[9px] text-white/30 uppercase tracking-widest mt-1">
                      {b.category}
                    </p>
                  )}
                </div>
              </div>
            ))}
          </div>
        )}
      </main>

      {selectedBook && (
        <div
          className="fixed inset-0 z-[60] flex items-end justify-center bg-black/70 backdrop-blur-sm"
          onClick={() => setSelectedBook(null)}
        >
          <div
            className="glass-card w-full max-w-[460px] rounded-t-3xl border-t border-white/10 p-6 pb-10 max-h-[85vh] overflow-y-auto"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex justify-end mb-2">
              <button onClick={() => setSelectedBook(null)} className="text-white/40 hover:text-white/70">
                <X size={20} />
              </button>
            </div>
            <div className="flex gap-4 mb-4">
              <div className="w-24 h-32 rounded-xl overflow-hidden bg-white/5 shrink-0">
                {selectedBook.thumbnail ? (
                  <img src={selectedBook.thumbnail} alt={selectedBook.title} className="w-full h-full object-cover" />
                ) : (
                  <div className="w-full h-full flex items-center justify-center">
                    <Library size={24} className="text-white/15" />
                  </div>
                )}
              </div>
              <div className="flex-1">
                <h2 className="font-space text-xl font-bold tracking-tight">{selectedBook.title}</h2>
                {selectedBook.author && <p className="text-white/50 text-sm mt-1">{selectedBook.author}</p>}
                {selectedBook.category && (
                  <p className="font-mono text-[10px] text-white/30 uppercase tracking-widest mt-2">
                    {selectedBook.category}
                  </p>
                )}
                <span
                  className={`inline-block mt-3 text-[10px] font-bold px-2 py-1 rounded-full ${
                    selectedBook.price > 0 ? "bg-white/10 text-[#cf3]" : "bg-[#cf3] text-black"
                  }`}
                >
                  {selectedBook.price > 0 ? `₹${selectedBook.price}` : "FREE"}
                </span>
              </div>
            </div>
            <p className="text-white/60 text-sm leading-relaxed mb-6">
              {selectedBook.description || "No description available for this book."}
            </p>
            <button
              onClick={() => {
                selectedBook.pdfLink && window.open(selectedBook.pdfLink, "_blank");
              }}
              className="w-full bg-[#cf3] text-black font-bold py-3.5 rounded-xl text-sm uppercase tracking-wide hover:opacity-90 transition"
            >
              Download Now
            </button>
          </div>
        </div>
      )}

      <BottomNav active="ebooks" onNavigate={onNavigate} />
    </div>
  );
}
