import { useEffect, useState } from "react";
import { Institution } from "../types";
import { Menu, Bell, Wallet, ChevronRight } from "lucide-react";
import { ref, get } from "firebase/database";
import { db } from "../firebase";
import { defaultInstitutions } from "../data";
import BottomNav from "./BottomNav";

interface InstituteSelectProps {
  onNavigate: (view: string) => void;
  onSelect: (id: string, name: string) => void;
  institutions?: Institution[];
}

export default function InstituteSelect({ onNavigate, onSelect, institutions }: InstituteSelectProps) {
  const [logos, setLogos] = useState<Record<string, string>>({});
  const triggerMenu = () => window.dispatchEvent(new CustomEvent("openMenu"));

  useEffect(() => {
    const logosRef = ref(db, "settings/instituteLogos");
    get(logosRef).then((snap) => {
      if (snap.exists()) {
        setLogos(snap.val());
      }
    });
  }, []);

  const list = institutions || defaultInstitutions;

  return (
    <div className="flex flex-col min-h-screen pb-32">
      <header className="fixed top-0 left-0 right-0 z-50 bg-black/60 backdrop-blur-lg border-b border-white/10 flex justify-between items-center px-6 py-4 max-w-[460px] mx-auto">
        <div className="flex items-center gap-3">
          <button className="text-[#cf3] cursor-pointer" onClick={triggerMenu}>
            <Menu size={24} />
          </button>
          <span className="font-space font-black text-2xl tracking-tighter text-[#cf3]">
            Edutech
          </span>
        </div>
        <div className="flex items-center gap-2">
          <button
            onClick={() => onNavigate("notifications")}
            className="flex items-center justify-center w-9 h-9 rounded-full border border-white/10 bg-white/5"
          >
            <Bell size={18} className="text-[#cf3]" />
          </button>
          <button
            onClick={() => onNavigate("wallet")}
            className="flex items-center gap-1.5 pl-2.5 pr-3 py-1.5 rounded-full border border-[#cf3]/40 bg-[#cf3]/10"
          >
            <Wallet size={18} className="text-[#cf3]" />
            <span className="font-space font-bold text-[#cf3] text-sm">₹0</span>
          </button>
          <div
            onClick={() => onNavigate("profile")}
            className="w-10 h-10 rounded-full border border-white/10 overflow-hidden bg-gradient-to-br from-[#cf3] to-[#1A2600] flex items-center justify-center cursor-pointer hover:opacity-80 transition"
          >
            <span className="font-space font-bold text-black text-lg">U</span>
          </div>
        </div>
      </header>

      <main className="pt-28 px-6">
        <section className="mb-8">
          <h1 className="font-space text-3xl font-semibold tracking-tight">Pick your institute</h1>
          <p className="text-white/40 text-sm mt-1">Direct access to course platforms.</p>
        </section>

        <div className="flex flex-col gap-4">
          {list.map((inst) => (
            <button
              key={inst.id}
              onClick={() => onSelect(inst.id, inst.name)}
              className="glass-card rounded-xl p-5 flex items-center gap-4 group hover:border-[#cf3]/40 transition-all text-left"
            >
              <div
                className="w-16 h-16 rounded-xl border border-white/10 shrink-0 flex items-center justify-center font-space font-black text-xl text-white overflow-hidden"
                style={
                  logos[inst.id]
                    ? {}
                    : { background: `linear-gradient(135deg, ${inst.color || "#cf3"}, #000)` }
                }
              >
                {logos[inst.id] ? (
                  <img src={logos[inst.id]} alt={inst.name} className="w-full h-full object-cover" />
                ) : (
                  inst.initial
                )}
              </div>
              <div className="flex flex-col flex-1 min-w-0">
                <h3 className="font-space font-bold text-lg text-white group-hover:text-[#cf3] transition truncate">
                  {inst.name}
                </h3>
                <p className="text-white/40 font-mono text-[10px] uppercase tracking-widest">{inst.tag}</p>
              </div>
              <ChevronRight className="text-white/20 group-hover:text-[#cf3] transition" />
            </button>
          ))}
        </div>
      </main>

      <BottomNav active="institute" onNavigate={onNavigate} />
    </div>
  );
}
