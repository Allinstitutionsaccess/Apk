import { useEffect, useState } from "react";
import { User } from "../types";
import { ArrowLeft, Gift, Copy, Check, Share2, ReceiptText, Users } from "lucide-react";
import { ref, get } from "firebase/database";
import { db } from "../firebase";
import { REFERRAL_REWARD } from "../data";

interface ReferPageProps {
  user: User;
  onNavigate: (view: string) => void;
}

export default function ReferPage({ user, onNavigate }: ReferPageProps) {
  const [copiedCode, setCopiedCode] = useState(false);
  const [copiedLink, setCopiedLink] = useState(false);
  const [referredUsers, setReferredUsers] = useState<User[]>([]);

  useEffect(() => {
    // Read all users to find who was referred by current user
    const usersRef = ref(db, "users");
    get(usersRef).then((snap) => {
      if (snap.exists()) {
        const data = snap.val();
        const list = Object.entries(data).map(([uid, u]: any) => ({
          ...u,
          uid,
        }));
        setReferredUsers(list.filter((u) => u.referredBy === user.uid));
      }
    });
  }, [user.uid]);

  const inviteCode = user.inviteCode || `EDU-${user.uid.slice(-8).toUpperCase()}`;
  const inviteLink = `${window.location.origin}/register?ref=${inviteCode}`;

  const handleCopyCode = () => {
    navigator.clipboard.writeText(inviteCode);
    setCopiedCode(true);
    setTimeout(() => setCopiedCode(false), 2000);
  };

  const handleCopyLink = () => {
    navigator.clipboard.writeText(inviteLink);
    setCopiedLink(true);
    setTimeout(() => setCopiedLink(false), 2000);
  };

  const handleShareWhatsApp = () => {
    const text = `Join me on Edutech and let's learn together! Use my invite code: ${inviteCode} or sign up using this link: ${inviteLink}`;
    window.open(`https://wa.me/?text=${encodeURIComponent(text)}`, "_blank");
  };

  return (
    <div className="flex flex-col min-h-screen bg-app-bg">
      <header className="fixed top-0 left-0 right-0 z-50 bg-black/70 backdrop-blur-xl border-b border-white/10 flex items-center px-6 py-4 max-w-[460px] mx-auto">
        <button
          onClick={() => onNavigate("home")}
          className="w-10 h-10 rounded-full border border-white/10 bg-white/5 flex items-center justify-center mr-3 hover:bg-white/10 transition"
        >
          <ArrowLeft size={20} className="text-white/80" />
        </button>
        <span className="font-space font-black text-xl tracking-tighter text-brand-accent">Refer & Earn</span>
      </header>

      <main className="pt-28 px-5">
        <section
          className="rounded-3xl p-6 mb-6 relative overflow-hidden border border-brand-accent/40"
          style={{
            background:
              "radial-gradient(circle at top right, rgba(204,255,51,0.22), transparent 60%), linear-gradient(135deg, rgba(204,255,51,0.10), rgba(0,0,0,0.5))",
          }}
        >
          <div className="absolute -top-12 -right-10 w-44 h-44 rounded-full bg-brand-accent/20 blur-3xl" />
          <div className="relative">
            <p className="font-mono text-[10px] uppercase tracking-widest text-brand-accent mb-2">Invite Friends</p>
            <h1 className="font-space text-3xl font-bold tracking-tight mb-2">Get ₹{REFERRAL_REWARD} Free</h1>
            <p className="text-white/60 text-sm leading-relaxed">
              Share your invite code with your friends and family. Once they enroll in their first batch, you get ₹{REFERRAL_REWARD} directly in your wallet!
            </p>
          </div>
        </section>

        <section className="glass-card rounded-2xl p-5 mb-6 space-y-4">
          <div className="space-y-1">
            <span className="text-xs text-white/40 uppercase font-mono tracking-wider pl-1">Your Invite Code</span>
            <div className="flex items-center justify-between p-3.5 bg-white/5 rounded-xl border border-white/10">
              <span className="font-space font-black text-xl text-brand-accent tracking-widest">{inviteCode}</span>
              <button onClick={handleCopyCode} className="p-2 bg-white/5 rounded-lg text-white/60 hover:text-white transition">
                {copiedCode ? <Check size={18} className="text-green-500" /> : <Copy size={18} />}
              </button>
            </div>
          </div>

          <div className="space-y-1">
            <span className="text-xs text-white/40 uppercase font-mono tracking-wider pl-1">Invite Link</span>
            <div className="flex items-center justify-between p-3 bg-white/5 rounded-xl border border-white/10">
              <span className="text-sm text-white/60 truncate mr-4">{inviteLink}</span>
              <button onClick={handleCopyLink} className="p-2 bg-white/5 rounded-lg text-white/60 hover:text-white transition flex-shrink-0">
                {copiedLink ? <Check size={18} className="text-green-500" /> : <Copy size={18} />}
              </button>
            </div>
          </div>

          <button
            onClick={handleShareWhatsApp}
            className="w-full bg-[#25D366] text-white font-space font-bold py-4 rounded-xl text-sm uppercase tracking-wide hover:opacity-90 transition flex items-center justify-center gap-2"
          >
            <Share2 size={18} /> Share on WhatsApp
          </button>
        </section>

        <section className="glass-card rounded-2xl p-5">
          <div className="flex items-center gap-3 mb-6">
            <div className="w-10 h-10 rounded-xl bg-white/5 flex items-center justify-center text-brand-accent">
              <Users size={20} />
            </div>
            <h2 className="font-space text-lg font-semibold">Friends Joined ({referredUsers.length})</h2>
          </div>

          {referredUsers.length === 0 ? (
            <div className="flex flex-col items-center justify-center py-10 opacity-30 gap-3">
              <Users size={32} />
              <p className="text-sm font-mono uppercase tracking-widest text-center">No invites yet</p>
            </div>
          ) : (
            <div className="space-y-3">
              {referredUsers.map((item, idx) => (
                <div key={item.uid || idx} className="flex items-center justify-between p-3.5 bg-white/5 rounded-xl border border-white/5">
                  <div>
                    <p className="font-bold text-sm text-white">{item.name}</p>
                    <p className="text-xs text-white/40 mt-0.5">
                      {item.referralRewardSent ? "Batch joined" : "Signed up • batch pending"}
                    </p>
                  </div>
                  <span
                    className={`text-[10px] font-bold px-2.5 py-1 rounded-full uppercase tracking-wide ${
                      item.referralRewardSent ? "bg-brand-accent text-black" : "bg-yellow-500/15 text-yellow-400"
                    }`}
                  >
                    {item.referralRewardSent ? `+₹${REFERRAL_REWARD}` : "Pending"}
                  </span>
                </div>
              ))}
            </div>
          )}
        </section>
      </main>
    </div>
  );
}
