import { useEffect, useState } from "react";
import { User, Batch } from "../types";
import { Menu, Bell, Wallet, School, ArrowRight, BookOpen } from "lucide-react";
import { ref, get } from "firebase/database";
import { db } from "../firebase";
import { qs } from "../firebase_helper"; // We'll create this simple helper to subscribe to RTDB or use standard ref/onValue
import BottomNav from "./BottomNav";

interface HomeProps {
  user: User;
  onNavigate: (view: string) => void;
  batches: Batch[];
  onSelectBatch: (batch: Batch) => void;
  onSelectInstitute: (id: string, name: string) => void;
}

export default function Home({ user, onNavigate, batches, onSelectBatch, onSelectInstitute }: HomeProps) {
  const [walletBalance, setWalletBalance] = useState(0);
  const [recommendedIds, setRecommendedIds] = useState<string[]>([]);

  // Simple menu trigger
  const triggerMenu = () => window.dispatchEvent(new CustomEvent("openMenu"));

  useEffect(() => {
    // Read real-time wallet balance
    const walletRef = ref(db, `users/${user.uid}/wallet`);
    get(walletRef).then((snap) => {
      if (snap.exists()) {
        setWalletBalance(snap.val().balance || 0);
      }
    });

    // Read recommended IDs
    const recRef = ref(db, "settings/recommended");
    get(recRef).then((snap) => {
      if (snap.exists()) {
        const val = snap.val();
        setRecommendedIds(Array.isArray(val) ? val : Object.values(val));
      }
    });
  }, [user.uid]);

  const recommendedBatches = (batches || []).filter((b) => recommendedIds.includes(b.id));

  return (
    <div className="flex flex-col min-h-screen pb-32">
      <header className="fixed top-0 left-0 right-0 z-50 bg-black/60 backdrop-blur-lg border-b border-white/10 flex justify-between items-center px-6 py-4 max-w-[460px] mx-auto">
        <div className="flex items-center gap-3">
          <button className="text-[#cf3] cursor-pointer" onClick={triggerMenu}>
            <Menu size={24} />
          </button>
          <span className="font-space font-black text-2xl tracking-tighter text-[#cf3]">
            Edutech
          </span>
        </div>
        <div className="flex items-center gap-2">
          <button
            onClick={() => onNavigate("notifications")}
            className="flex items-center justify-center w-9 h-9 rounded-full border border-white/10 bg-white/5"
          >
            <Bell size={18} className="text-[#cf3]" />
          </button>
          <button
            onClick={() => onNavigate("wallet")}
            className="flex items-center gap-1.5 pl-2.5 pr-3 py-1.5 rounded-full border border-[#cf3]/40 bg-[#cf3]/10"
          >
            <Wallet size={18} className="text-[#cf3]" />
            <span className="font-space font-bold text-[#cf3] text-sm">₹{walletBalance}</span>
          </button>
          <div
            onClick={() => onNavigate("profile")}
            className="w-10 h-10 rounded-full border border-white/10 overflow-hidden bg-gradient-to-br from-[#cf3] to-[#1A2600] flex items-center justify-center cursor-pointer hover:opacity-80 transition"
          >
            {user.profilePicture ? (
              <img src={user.profilePicture} alt={user.name} className="w-full h-full object-cover" />
            ) : (
              <span className="font-space font-bold text-black text-lg">
                {user.name?.[0]?.toUpperCase() || "U"}
              </span>
            )}
          </div>
        </div>
      </header>

      <main className="pt-28 px-5">
        <section className="mb-6">
          <p className="font-mono text-[#cf3] text-xs uppercase tracking-widest mb-1">Good day 👋</p>
          <h1 className="font-space text-3xl font-bold tracking-tight">
            Welcome back, {user.name.split(" ")[0]}!
          </h1>
          <p className="text-white/40 text-sm mt-1">Ready to continue your learning journey?</p>
        </section>

        <section className="mb-6">
          <div
            className="relative overflow-hidden rounded-2xl p-5 border border-[#cf3]/40 cursor-pointer group"
            style={{
              background:
                "radial-gradient(circle at top right, rgba(204,255,51,0.22), transparent 60%), linear-gradient(135deg, rgba(204,255,51,0.10), rgba(0,0,0,0.5))",
            }}
            onClick={() => onNavigate("institute")}
          >
            <div className="flex items-center justify-between">
              <div>
                <div className="flex items-center gap-2 mb-2">
                  <School size={20} className="text-[#cf3]" />
                  <span className="font-mono text-[10px] uppercase tracking-widest text-[#cf3]">Explore</span>
                </div>
                <h2 className="font-space text-xl font-bold mb-1">Pick Your Institute</h2>
                <p className="text-white/50 text-sm">Browse top platforms & enroll in batches.</p>
              </div>
              <div className="w-12 h-12 rounded-full bg-[#cf3]/20 border border-[#cf3]/40 flex items-center justify-center group-hover:bg-[#cf3]/30 transition">
                <ArrowRight size={24} className="text-[#cf3]" />
              </div>
            </div>
          </div>
        </section>

        <section className="grid grid-cols-2 gap-4">
          <div onClick={() => onNavigate("mycourses")} className="glass-card rounded-2xl p-4 flex flex-col gap-2 cursor-pointer hover:bg-white/5 transition">
            <div className="w-10 h-10 rounded-lg bg-white/5 flex items-center justify-center text-[#cf3]">
              <BookOpen size={20} />
            </div>
            <p className="text-sm font-semibold">My Courses</p>
            <p className="text-xs text-white/40">Resume learning</p>
          </div>
          <div onClick={() => onNavigate("refer")} className="glass-card rounded-2xl p-4 flex flex-col gap-2 cursor-pointer hover:bg-white/5 transition">
            <div className="w-10 h-10 rounded-lg bg-white/5 flex items-center justify-center text-[#cf3]">
              <svg size={20} fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24" className="w-5 h-5">
                <path d="M20 12l-8 8-8-8M12 4v16" strokeLinecap="round" strokeLinejoin="round" />
              </svg>
            </div>
            <p className="text-sm font-semibold">Refer & Earn</p>
            <p className="text-xs text-white/40">Get ₹50 per friend</p>
          </div>
        </section>

        {recommendedBatches.length > 0 && (
          <section className="mt-6">
            <p className="font-mono text-[#cf3] text-xs uppercase tracking-widest mb-3">⭐ Recommended for You</p>
            <div className="flex flex-col gap-3">
              {recommendedBatches.map((b) => (
                <div
                  key={b.id}
                  className="glass-card rounded-2xl overflow-hidden border border-[#cf3]/20 hover:border-[#cf3]/50 transition cursor-pointer group"
                  onClick={() => onSelectBatch(b)}
                >
                  {b.thumbnail && (
                    <div className="h-28 w-full overflow-hidden relative">
                      <img src={b.thumbnail} alt={b.title} className="w-full h-full object-cover" />
                      <div className="absolute inset-0 bg-gradient-to-t from-black/70 to-transparent" />
                    </div>
                  )}
                  <div className="p-4 flex items-center justify-between">
                    <div className="min-w-0">
                      <p className="font-space font-bold text-base truncate text-white group-hover:text-[#cf3] transition">
                        {b.title}
                      </p>
                      <p className="font-mono text-[10px] text-white/40 uppercase tracking-widest mt-0.5">
                        {b.tag}
                      </p>
                      <div className="flex items-center gap-2 mt-1">
                        <span className="text-[#cf3] font-bold text-sm">
                          ₹{(b.discountPrice || 0).toLocaleString()}
                        </span>
                        {b.actualPrice > b.discountPrice && (
                          <span className="text-white/30 text-xs line-through">
                            ₹{(b.actualPrice || 0).toLocaleString()}
                          </span>
                        )}
                      </div>
                    </div>
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        onSelectBatch(b);
                      }}
                      className="shrink-0 ml-3 px-4 py-2 rounded-full bg-[#cf3] text-black text-xs font-bold hover:bg-[#b8e62e] transition"
                    >
                      Enroll
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </section>
        )}
      </main>

      <BottomNav active="home" onNavigate={onNavigate} />
    </div>
  );
}
