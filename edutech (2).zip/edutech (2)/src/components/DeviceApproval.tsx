import { ShieldAlert, LogOut } from "lucide-react";
import { signOut } from "firebase/auth";
import { auth } from "../firebase";
import { getDeviceId } from "../utils";

interface DeviceApprovalProps {
  user: any;
  onNavigate: (view: string) => void;
}

export default function DeviceApproval({ user, onNavigate }: DeviceApprovalProps) {
  const currentDeviceId = getDeviceId();
  const currentDevice = user.devices?.[currentDeviceId];
  const status = currentDevice?.status || "pending";

  const handleSignOut = async () => {
    await signOut(auth);
    onNavigate("login");
  };

  return (
    <div
      className="flex flex-col relative min-h-screen px-6 items-center justify-center text-center"
      style={{
        backgroundImage: "radial-gradient(circle at 50% 0%, rgba(204,255,51,0.15) 0%, rgba(10,11,9,1) 55%)",
      }}
    >
      <div className="w-24 h-24 rounded-full bg-red-500/10 flex items-center justify-center mb-6 border border-red-500/20">
        <div className="w-full h-full rounded-full bg-gradient-to-br from-red-500/20 to-transparent flex items-center justify-center">
          <ShieldAlert size={40} className="text-red-500" />
        </div>
      </div>

      <h1 className="text-2xl font-bold mb-3 tracking-tight">
        {status === "revoked" ? "Device Access Revoked" : "Device Not Recognized"}
      </h1>

      <p className="text-white/60 text-sm mb-10 leading-relaxed max-w-sm">
        {status === "revoked"
          ? "Access from this device has been revoked by you or an administrator."
          : "You are trying to log in from a new device. For security reasons, this requires authorization. You can approve this device from your already logged-in device (under Security), or contact an administrator."}
      </p>

      <button
        onClick={handleSignOut}
        className="flex items-center gap-2 text-white/50 hover:text-white transition bg-white/5 px-6 py-3 rounded-full border border-white/10"
      >
        <LogOut size={18} /> Sign Out
      </button>
    </div>
  );
}
