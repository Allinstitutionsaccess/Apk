import { useState, FormEvent, ChangeEvent } from "react";
import { User } from "../types";
import { ArrowLeft, User as UserIcon, Camera, Save, Phone, Mail, Award } from "lucide-react";
import { ref, update } from "firebase/database";
import { db } from "../firebase";

interface ProfilePageProps {
  user: User;
  onNavigate: (view: string) => void;
}

export default function ProfilePage({ user, onNavigate }: ProfilePageProps) {
  const [name, setName] = useState(user.name);
  const [phone, setPhone] = useState(user.phone || "");
  const [profilePicture, setProfilePicture] = useState(user.profilePicture || "");
  const [saving, setSaving] = useState(false);

  const compressImage = (file: File, maxWidth = 200): Promise<string> =>
    new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = (e) => {
        const img = new Image();
        img.onload = () => {
          const canvas = document.createElement("canvas");
          let width = img.width;
          let height = img.height;
          if (width > maxWidth) {
            height = Math.round((height * maxWidth) / width);
            width = maxWidth;
          }
          canvas.width = width;
          canvas.height = height;
          const ctx = canvas.getContext("2d");
          if (!ctx) {
            resolve(e.target?.result as string);
            return;
          }
          ctx.drawImage(img, 0, 0, width, height);
          resolve(canvas.toDataURL("image/jpeg", 0.5));
        };
        img.onerror = () => {
          resolve(e.target?.result as string);
        };
        img.src = e.target?.result as string;
      };
      reader.onerror = () => reject("File read error");
      reader.readAsDataURL(file);
    });

  const handlePictureChange = async (e: ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      if (file.size > 5 * 1024 * 1024) {
        alert("File size too large (max 5MB)");
        return;
      }
      try {
        const compressed = await compressImage(file, 200);
        setProfilePicture(compressed);
      } catch (err) {
        alert("Failed to process image: " + String(err));
      }
    }
  };

  const handleSave = async (e: FormEvent) => {
    e.preventDefault();
    if (!name.trim()) return alert("Name is required");

    setSaving(true);
    try {
      const userRef = ref(db, `users/${user.uid}`);
      await update(userRef, {
        name: name.trim(),
        phone: phone.trim() || null,
        profilePicture: profilePicture || null,
      });
      alert("Profile updated successfully!");
    } catch (err: any) {
      alert("Failed to update profile: " + err.message);
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="flex flex-col min-h-screen bg-app-bg">
      <header className="fixed top-0 left-0 right-0 z-50 bg-black/70 backdrop-blur-xl border-b border-brand-accent/30 flex items-center px-6 py-4 max-w-[460px] mx-auto">
        <button
          onClick={() => onNavigate("home")}
          className="w-10 h-10 rounded-full border border-white/10 bg-white/5 flex items-center justify-center mr-3 hover:bg-white/10 transition"
        >
          <ArrowLeft size={20} className="text-white/80" />
        </button>
        <span className="font-space font-black text-xl tracking-tighter text-brand-accent">My Profile</span>
      </header>

      <main className="pt-24 px-5 pb-10">
        <div className="flex flex-col items-center mb-8">
          <div className="relative group cursor-pointer">
            <div className="w-24 h-24 rounded-full border border-white/10 overflow-hidden bg-gradient-to-br from-brand-accent to-[#1A2600] flex items-center justify-center shadow-xl shadow-brand-accent/20 mb-4 transition-transform group-hover:scale-105">
              {profilePicture === "uploading..." ? (
                <span className="font-space font-medium text-black text-xs">Uploading...</span>
              ) : profilePicture ? (
                <img src={profilePicture} alt={user.name} className="w-full h-full object-cover" />
              ) : (
                <span className="font-space font-bold text-black text-4xl">
                  {user.name?.[0]?.toUpperCase() || "U"}
                </span>
              )}
            </div>
            <label className="absolute inset-x-0 bottom-4 flex justify-center cursor-pointer">
              <div className="bg-black/80 rounded-full p-1.5 border border-white/20">
                <Camera size={14} className="text-white" />
              </div>
              <input type="file" onChange={handlePictureChange} accept="image/*" className="hidden" />
            </label>
          </div>
          <h2 className="font-space font-bold text-2xl">{user.name}</h2>
          <p className="text-white/40 text-sm font-mono">{user.email}</p>
          <div className="mt-2 inline-flex items-center gap-1.5 bg-white/5 border border-white/10 rounded-full px-3 py-1 text-[11px] font-mono text-white/50">
            Invite Code: EDU-{user.uid.slice(-8).toUpperCase()}
          </div>
        </div>

        <section className="glass-card rounded-2xl p-6">
          <form onSubmit={handleSave} className="space-y-4">
            <div className="space-y-1.5">
              <label className="text-xs uppercase tracking-widest font-mono text-white/50">Full Name</label>
              <div className="relative">
                <UserIcon size={18} className="absolute left-4 top-1/2 -translate-y-1/2 text-white/40" />
                <input
                  type="text"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  className="bg-white/5 border border-white/10 rounded-xl pl-11 pr-4 py-3 w-full text-white outline-none focus:border-brand-accent transition"
                  required
                />
              </div>
            </div>

            <div className="space-y-1.5">
              <label className="text-xs uppercase tracking-widest font-mono text-white/50">Phone Number</label>
              <div className="relative">
                <Phone size={18} className="absolute left-4 top-1/2 -translate-y-1/2 text-white/40" />
                <input
                  type="tel"
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                  placeholder="e.g. +91 9876543210"
                  className="bg-white/5 border border-white/10 rounded-xl pl-11 pr-4 py-3 w-full text-white outline-none focus:border-brand-accent transition"
                />
              </div>
            </div>

            <div className="space-y-1.5 opacity-60">
              <label className="text-xs uppercase tracking-widest font-mono text-white/50">Email Address (Read-only)</label>
              <div className="relative">
                <Mail size={18} className="absolute left-4 top-1/2 -translate-y-1/2 text-white/40" />
                <input
                  type="email"
                  value={user.email}
                  readOnly
                  className="bg-white/5 border border-white/10 rounded-xl pl-11 pr-4 py-3 w-full text-white outline-none cursor-not-allowed"
                />
              </div>
            </div>

            <button
              type="submit"
              disabled={saving}
              className="w-full mt-4 flex items-center justify-center gap-2 bg-brand-accent text-black font-bold py-3.5 rounded-full hover:bg-[#b8e62e] transition shadow-lg shadow-brand-accent/20"
            >
              <Save size={18} /> {saving ? "Saving..." : "Save Changes"}
            </button>
          </form>
        </section>
      </main>
    </div>
  );
}
