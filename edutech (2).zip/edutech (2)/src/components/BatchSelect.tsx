import { Batch, Submission, User } from "../types";
import { ArrowLeft, School, ExternalLink } from "lucide-react";

interface BatchSelectProps {
  institute: { id: string; name: string } | null;
  batches: Batch[];
  submissions: Submission[];
  user: User | null;
  onNavigate: (view: string) => void;
  onSelectBatch: (batch: Batch) => void;
}

export default function BatchSelect({
  institute,
  batches,
  submissions,
  user,
  onNavigate,
  onSelectBatch,
}: BatchSelectProps) {
  const filteredBatches = batches.filter(
    (b) => b.institute === "all" || b.institute === institute?.id
  );

  const getApprovedSubmission = (batchId: string) => {
    if (!user) return null;
    return submissions.find(
      (sub) => sub.userUid === user.uid && sub.batchId === batchId && sub.status === "approved"
    );
  };

  return (
    <div className="flex flex-col min-h-screen">
      <header className="fixed top-0 left-0 right-0 z-50 bg-black/60 backdrop-blur-xl border-b border-white/10 flex justify-between items-center px-6 py-4 max-w-[460px] mx-auto">
        <div className="flex items-center gap-3">
          <button onClick={() => onNavigate("institute")} className="text-[#cf3]">
            <ArrowLeft size={24} />
          </button>
          <span className="font-space font-black text-2xl tracking-tighter text-[#cf3]">
            Edutech
          </span>
        </div>
      </header>

      <main className="pt-24 pb-32 px-5">
        <div className="mb-8">
          <p className="text-[#cf3] font-mono text-xs uppercase tracking-widest mb-2">
            {institute?.name || "All Institutes"}
          </p>
          <h1 className="font-space text-3xl font-semibold mb-2">Choose Your Batch</h1>
          <p className="text-white/60 text-sm">Select a program to start your academic journey.</p>
        </div>

        <div className="grid gap-6">
          {filteredBatches.map((batch) => (
            <div
              key={batch.id}
              className="relative bg-white/5 backdrop-blur-xl rounded-xl border border-white/10 overflow-hidden group hover:border-[#cf3]/50 transition-colors"
            >
              <div
                className="h-44 w-full relative overflow-hidden border-b border-white/5 bg-gradient-to-br from-black/80 to-black/20"
                style={{ backgroundColor: batch.color + "22" }}
              >
                {batch.thumbnail && batch.thumbnail.trim() !== "" ? (
                  <img
                    src={batch.thumbnail}
                    alt={batch.title}
                    className="absolute inset-0 w-full h-full object-cover"
                  />
                ) : (
                  <div className="absolute inset-0 flex items-center justify-center">
                    <School className="text-white/30" size={64} />
                  </div>
                )}
                <div className="absolute top-4 left-4 z-10 flex gap-2">
                  <span className="px-3 py-1 bg-[#cf3] text-black text-xs font-bold rounded-full">
                    ₹{batch.discountPrice.toLocaleString()}
                  </span>
                  {batch.actualPrice > batch.discountPrice && (
                    <span className="text-white/60 text-xs line-through">
                      ₹{batch.actualPrice.toLocaleString()}
                    </span>
                  )}
                </div>
                <div className="absolute bottom-4 left-4 z-10">
                  <span className="px-3 py-1 bg-black/60 rounded-full border border-[#cf3]/30 text-[10px] font-semibold uppercase text-[#cf3] tracking-wider">
                    {batch.tag}
                  </span>
                </div>
              </div>

              <div className="p-5">
                <h2 className="font-space text-xl font-semibold mb-4">{batch.title}</h2>
                <div className="flex items-center justify-between">
                  <span className="text-white/40 text-xs">{batch.members} enrolled</span>
                  {getApprovedSubmission(batch.id) ? (
                    <button
                      onClick={() => {
                        const sub = getApprovedSubmission(batch.id);
                        if (sub?.accessLink) {
                          window.open(sub.accessLink, "_blank");
                        } else {
                          onNavigate("mycourses");
                        }
                      }}
                      className="flex items-center gap-2 bg-emerald-500/20 hover:bg-emerald-500/30 text-emerald-400 border border-emerald-500/20 px-4 py-2.5 rounded-lg text-sm font-semibold transition shadow-lg"
                    >
                      Open Course <ExternalLink size={16} />
                    </button>
                  ) : (
                    <button
                      onClick={() => onSelectBatch(batch)}
                      className="flex items-center gap-2 bg-[#8A2BE2] hover:bg-[#9d4edd] text-white px-4 py-2.5 rounded-lg text-sm font-semibold transition shadow-lg"
                    >
                      Enroll Now <ArrowLeft size={16} className="rotate-180" />
                    </button>
                  )}
                </div>
              </div>
            </div>
          ))}
        </div>
      </main>
    </div>
  );
}
