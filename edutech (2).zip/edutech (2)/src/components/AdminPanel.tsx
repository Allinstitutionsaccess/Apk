import { useState, useEffect, ChangeEvent, FormEvent } from "react";
import { User, Batch, Submission, Ebook, Institution, Device } from "../types";
import {
  LayoutDashboard,
  List,
  Library,
  CreditCard,
  School,
  GraduationCap,
  Wallet,
  Smartphone,
  LogOut,
  X,
  Plus,
  RefreshCcw,
  UploadCloud,
  Pen,
  Trash2,
  Check,
  ShieldAlert,
  Monitor,
  Menu,
} from "lucide-react";
import { ref, get, set, update, push, remove } from "firebase/database";
import { db, auth } from "../firebase";
import { signOut } from "firebase/auth";
import { defaultInstitutions, tx, REFERRAL_REWARD, defaultQr } from "../data";
import RecommendPanel from "./RecommendPanel";

interface AdminPanelProps {
  user: User;
  batches: Batch[];
  ebooks: Ebook[];
  submissions: Submission[];
  institutions?: Institution[];
  onNavigate: (view: string) => void;
}

export default function AdminPanel({
  user,
  batches,
  ebooks,
  submissions,
  institutions,
  onNavigate,
}: AdminPanelProps) {
  const [activeTab, setActiveTab] = useState("dashboard");
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [searchTerm, setSearchTerm] = useState("");
  const [editingBatchId, setEditingBatchId] = useState<string | null>(null);
  const [confirmRemoveQr, setConfirmRemoveQr] = useState(false);

  const [batchForm, setBatchForm] = useState<Partial<Batch>>({
    color: "#22c55e",
    institute: "all",
    members: "+1",
    thumbnail: "",
    description: "",
    upiId: "",
    upiPayLink: "",
    qrDataUrl: "",
    courseLink: "",
  });

  const [institutionLogos, setInstitutionLogos] = useState<Record<string, string>>({});
  const [paymentConfig, setPaymentConfig] = useState({
    upiId: defaultQr.upiId,
    qrDataUrl: defaultQr.qrDataUrl,
    payeeName: defaultQr.payeeName,
  });

  const [customInstitutions, setCustomInstitutions] = useState<Institution[]>([]);
  const [newInst, setNewInst] = useState({ name: "", tag: "Education", color: "#6366f1", logo: "" });

  const [allUsers, setAllUsers] = useState<User[]>([]);
  const [accessLinks, setAccessLinks] = useState<Record<string, string>>({});

  const [ebookForm, setEbookForm] = useState<Partial<Ebook>>({
    title: "",
    author: "",
    category: "",
    thumbnail: "",
    description: "",
    price: 0,
    pdfLink: "",
  });
  const [editingEbookId, setEditingEbookId] = useState<string | null>(null);

  useEffect(() => {
    // Load logos
    get(ref(db, "settings/instituteLogos")).then((snap) => {
      if (snap.exists()) setInstitutionLogos(snap.val());
    });

    // Load custom institutions
    get(ref(db, "settings/institutions")).then((snap) => {
      if (snap.exists()) {
        setCustomInstitutions(Object.values(snap.val()));
      }
    });

    // Load payment settings
    get(ref(db, "settings/payment")).then((snap) => {
      if (snap.exists()) {
        setPaymentConfig((prev) => ({ ...prev, ...snap.val() }));
      }
    });

    // Load users
    get(ref(db, "users")).then((snap) => {
      if (snap.exists()) {
        const uList = Object.entries(snap.val()).map(([uid, u]: any) => ({
          ...u,
          uid: u.uid || uid,
        }));
        setAllUsers(uList);
      }
    });
  }, []);

  const handleDeviceApprove = async (userUid: string, deviceId: string) => {
    if (confirm("Approve this device?")) {
      await update(ref(db, `users/${userUid}/devices/${deviceId}`), { status: "approved" });
      alert("Device approved!");
    }
  };

  const handleDeviceRevoke = async (userUid: string, deviceId: string) => {
    if (confirm("Revoke access for this device?")) {
      await update(ref(db, `users/${userUid}/devices/${deviceId}`), { status: "revoked" });
      alert("Device access revoked!");
    }
  };

  const handleDeviceDelete = async (userUid: string, deviceId: string) => {
    if (confirm("Delete this device record?")) {
      await remove(ref(db, `users/${userUid}/devices/${deviceId}`));
      alert("Device record deleted!");
    }
  };

  const compressImage = (file: File, maxWidth = 400): Promise<string> =>
    new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = (e) => {
        const img = new Image();
        img.onload = () => {
          const canvas = document.createElement("canvas");
          let width = img.width;
          let height = img.height;
          if (width > maxWidth) {
            height = Math.round((height * maxWidth) / width);
            width = maxWidth;
          }
          canvas.width = width;
          canvas.height = height;
          const ctx = canvas.getContext("2d");
          if (!ctx) {
            resolve(e.target?.result as string);
            return;
          }
          ctx.drawImage(img, 0, 0, width, height);
          resolve(canvas.toDataURL("image/jpeg", 0.5));
        };
        img.onerror = () => {
          resolve(e.target?.result as string);
        };
        img.src = e.target?.result as string;
      };
      reader.onerror = () => reject("File read error");
      reader.readAsDataURL(file);
    });

  const handleBatchThumbnailChange = async (e: ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      if (file.size > 5 * 1024 * 1024) return alert("File size too large (max 5MB)");
      try {
        setBatchForm((prev) => ({ ...prev, thumbnail: "uploading..." }));
        const compressed = await compressImage(file, 400);
        setBatchForm((prev) => ({ ...prev, thumbnail: compressed }));
      } catch (err) {
        console.error(err);
        setBatchForm((prev) => ({ ...prev, thumbnail: "" }));
      }
    }
  };

  const handleLogoUpload = async (instId: string, e: ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      if (file.size > 5 * 1024 * 1024) return alert("File size too large");
      try {
        const compressed = await compressImage(file, 200);
        await set(ref(db, `settings/instituteLogos/${instId}`), compressed);
        setInstitutionLogos((prev) => ({ ...prev, [instId]: compressed }));
        alert("Logo updated!");
      } catch (err: any) {
        alert("Upload failed: " + err.message);
      }
    }
  };

  const handleLogoRemove = async (instId: string) => {
    if (confirm("Remove logo?")) {
      await remove(ref(db, `settings/instituteLogos/${instId}`));
      setInstitutionLogos((prev) => {
        const updated = { ...prev };
        delete updated[instId];
        return updated;
      });
      alert("Logo removed!");
    }
  };

  const addInstitution = async () => {
    if (!newInst.name.trim()) return alert("Enter institution name");
    const instId = "inst_" + Date.now();
    const instData: Institution = {
      id: instId,
      name: newInst.name.trim(),
      tag: newInst.tag || "Education",
      color: newInst.color || "#6366f1",
      initial: newInst.name
        .trim()
        .split(" ")
        .map((w) => w[0])
        .join("")
        .toUpperCase()
        .slice(0, 2),
    };

    try {
      await set(ref(db, `settings/institutions/${instId}`), instData);
      if (newInst.logo) {
        await set(ref(db, `settings/instituteLogos/${instId}`), newInst.logo);
      }
      setCustomInstitutions((prev) => [...prev, instData]);
      setNewInst({ name: "", tag: "Education", color: "#6366f1", logo: "" });
      alert("Institution added!");
    } catch (err: any) {
      alert("Failed: " + err.message);
    }
  };

  const deleteInstitution = async (instId: string) => {
    if (!confirm("Delete this institution?")) return;
    try {
      await remove(ref(db, `settings/institutions/${instId}`));
      await remove(ref(db, `settings/instituteLogos/${instId}`));
      setCustomInstitutions((prev) => prev.filter((i) => i.id !== instId));
      alert("Institution deleted!");
    } catch (err: any) {
      alert("Failed: " + err.message);
    }
  };

  const handleWalletQrChange = async (e: ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      if (file.size > 5 * 1024 * 1024) return alert("File is too large");
      try {
        const compressed = await compressImage(file, 400);
        setPaymentConfig((prev) => ({ ...prev, qrDataUrl: compressed }));
      } catch (err: any) {
        alert(String(err));
      }
    }
  };

  const handleWalletUpiSubmit = async (e: FormEvent) => {
    e.preventDefault();
    await set(ref(db, "settings/payment"), paymentConfig);
    alert("Payment UPI updated!");
  };

  const handleRemoveWalletQr = async () => {
    try {
      const updated = { ...paymentConfig, qrDataUrl: "" };
      setPaymentConfig(updated);
      await set(ref(db, "settings/payment"), updated);
      setConfirmRemoveQr(false);
      alert("Global wallet QR removed!");
    } catch (err: any) {
      alert("Failed: " + err.message);
    }
  };

  const handleBatchSubmit = async (e: FormEvent) => {
    e.preventDefault();
    if (!batchForm.title || !batchForm.tag) return alert("Fill title and tag");

    try {
      if (editingBatchId) {
        await set(ref(db, `batches/${editingBatchId}`), { ...batchForm, id: editingBatchId });
        setEditingBatchId(null);
        alert("Batch updated!");
      } else {
        const newId = "b" + Date.now();
        await set(ref(db, `batches/${newId}`), { ...batchForm, id: newId });
        alert("Batch added!");
      }
      setBatchForm({
        color: "#22c55e",
        institute: "all",
        members: "+1",
        thumbnail: "",
        description: "",
        upiId: "",
        upiPayLink: "",
        qrDataUrl: "",
        courseLink: "",
      });
    } catch (err: any) {
      alert("Failed to save batch: " + err.message);
    }
  };

  const handleEditBatch = (b: Batch) => {
    setEditingBatchId(b.id);
    setBatchForm({ ...b });
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  const handleDeleteBatch = async (batchId: string) => {
    if (confirm("Delete this batch?")) {
      await remove(ref(db, `batches/${batchId}`));
      alert("Batch deleted!");
    }
  };

  const handleApproveSubmission = async (sub: Submission) => {
    if (sub.batchId === "WALLET_TOPUP") {
      if (!confirm("Approve this wallet top-up?")) return;
      try {
        const walletRef = ref(db, `users/${sub.userUid}/wallet`);
        const walletSnap = await get(walletRef);
        let walletData = walletSnap.val() || { balance: 0, history: [] };
        if (!walletData.history) walletData.history = [];
        walletData.balance += sub.amount;
        walletData.history.push({
          amount: sub.amount,
          reason: "Wallet Top-up Approved",
          date: new Date().toISOString(),
        });
        await update(ref(db, `users/${sub.userUid}`), { wallet: walletData });
        await update(ref(db, `paymentSubmissions/${sub.id}`), {
          status: "approved",
          updatedAt: new Date().toISOString(),
        });
        alert("Approved Top-up!");
      } catch (err: any) {
        alert("Failed to approve top up: " + err.message);
      }
    } else {
      const link = accessLinks[sub.id] || (batches.find((b) => b.id === sub.batchId)?.courseLink || "");
      if (!link) return alert("Enter an access link first");

      try {
        await update(ref(db, `paymentSubmissions/${sub.id}`), {
          status: "approved",
          accessLink: link,
          updatedAt: new Date().toISOString(),
        });

        // Referral crediting
        const uSnap = await get(ref(db, `users/${sub.userUid}`));
        if (uSnap.exists()) {
          const uVal = uSnap.val();
          if (uVal.referredBy && !uVal.referralRewardSent) {
            const rRef = ref(db, `users/${uVal.referredBy}/wallet`);
            const rSnap = await get(rRef);
            let rWallet = rSnap.val() || { balance: 0, history: [] };
            if (!rWallet.history) rWallet.history = [];
            rWallet.balance += REFERRAL_REWARD;
            rWallet.history.push({
              amount: REFERRAL_REWARD,
              reason: `Referral Reward for ${uVal.name}`,
              date: new Date().toISOString(),
            });
            await update(ref(db, `users/${uVal.referredBy}`), { wallet: rWallet });
            await update(ref(db, `users/${sub.userUid}`), { referralRewardSent: true });
          }
        }
        alert("Approved batch access!");
      } catch (err: any) {
        alert("Failed to approve: " + err.message);
      }
    }
  };

  const handleRejectSubmission = async (subId: string) => {
    if (confirm("Reject this payment?")) {
      await update(ref(db, `paymentSubmissions/${subId}`), {
        status: "rejected",
        updatedAt: new Date().toISOString(),
      });
      alert("Payment rejected!");
    }
  };

  const handleRevokeSubmission = async (sub: Submission) => {
    if (!confirm("Revoke this payment? User will lose access / wallet balance.")) return;
    try {
      if (sub.batchId === "WALLET_TOPUP") {
        const walletRef = ref(db, `users/${sub.userUid}/wallet`);
        const walletSnap = await get(walletRef);
        let walletData = walletSnap.val();
        if (walletData) {
          walletData.balance -= sub.amount;
          walletData.history.push({
            amount: -sub.amount,
            reason: "Wallet Top-up Revoked by Admin",
            date: new Date().toISOString(),
          });
          await update(ref(db, `users/${sub.userUid}`), { wallet: walletData });
        }
      }
      await update(ref(db, `paymentSubmissions/${sub.id}`), {
        status: "rejected",
        accessLink: null,
        updatedAt: new Date().toISOString(),
      });
      alert("Payment revoked!");
    } catch (err: any) {
      alert("Failed to revoke: " + err.message);
    }
  };

  const onEbookThumbUpload = async (e: ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      if (file.size > 5 * 1024 * 1024) return alert("File size too large (max 5MB)");
      try {
        setEbookForm((prev) => ({ ...prev, thumbnail: "uploading..." }));
        const compressed = await compressImage(file, 400);
        setEbookForm((prev) => ({ ...prev, thumbnail: compressed }));
      } catch (err) {
        console.error(err);
        setEbookForm((prev) => ({ ...prev, thumbnail: "" }));
      }
    }
  };

  const handleEbookSubmit = async (e: FormEvent) => {
    e.preventDefault();
    if (!ebookForm.title || !ebookForm.pdfLink) return alert("Fill title and PDF link");
    const priceNum = Number(ebookForm.price) || 0;
    const payload = {
      ...ebookForm,
      price: priceNum,
    };

    try {
      if (editingEbookId) {
        await set(ref(db, `ebooks/${editingEbookId}`), { ...payload, id: editingEbookId });
        setEditingEbookId(null);
        alert("Ebook updated!");
      } else {
        const newId = "eb" + Date.now();
        await set(ref(db, `ebooks/${newId}`), { ...payload, id: newId });
        alert("Ebook added!");
      }
      setEbookForm({
        title: "",
        author: "",
        category: "",
        thumbnail: "",
        description: "",
        price: 0,
        pdfLink: "",
      });
    } catch (err: any) {
      alert("Failed to save ebook: " + err.message);
    }
  };

  const handleEditEbook = (b: Ebook) => {
    setEditingEbookId(b.id);
    setEbookForm({ ...b });
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  const handleDeleteEbook = async (ebookId: string) => {
    if (confirm("Delete this ebook?")) {
      await remove(ref(db, `ebooks/${ebookId}`));
      alert("Ebook deleted!");
    }
  };

  const resetBatchesToDefault = async () => {
    if (!confirm("Reset to defaults?")) return;
    const data: Record<string, Batch> = {};
    tx.forEach((b) => {
      data[b.id] = b;
    });
    await set(ref(db, "batches"), data);
    alert("Batches reset to default!");
  };

  const activeInstList = [...defaultInstitutions, ...customInstitutions];

  return (
    <div className="flex min-h-screen bg-[#09090b] text-white">
      {sidebarOpen && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-sm z-[100] lg:hidden" onClick={() => setSidebarOpen(false)} />
      )}

      <aside
        className={`fixed inset-y-0 left-0 w-64 bg-black border-r border-white/10 z-[101] transition-transform duration-300 lg:static lg:translate-x-0 ${
          sidebarOpen ? "translate-x-0" : "-translate-x-full"
        }`}
      >
        <div className="p-6 border-b border-white/10 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <ShieldAlert size={24} className="text-brand-accent" />
            <span className="font-space font-black text-xl tracking-tighter text-brand-accent">Admin</span>
          </div>
          <button onClick={() => setSidebarOpen(false)} className="lg:hidden text-white/50">
            <X size={20} />
          </button>
        </div>

        <nav className="p-4 space-y-2">
          {[
            { id: "dashboard", label: "Dashboard", icon: LayoutDashboard },
            { id: "batches", label: "Batches", icon: List },
            { id: "ebooks", label: "Ebooks", icon: Library },
            { id: "payments", label: "Payments", icon: CreditCard },
            { id: "institutes", label: "Institutes", icon: School },
            { id: "recommend", label: "Recommend", icon: GraduationCap },
            { id: "walletupi", label: "Wallet UPI", icon: Wallet },
            { id: "devices", label: "Devices", icon: Smartphone },
          ].map((item) => (
            <button
              key={item.id}
              onClick={() => {
                setActiveTab(item.id);
                setSidebarOpen(false);
                setEditingBatchId(null);
                setBatchForm({
                  color: "#22c55e",
                  institute: "all",
                  members: "+1",
                  thumbnail: "",
                  description: "",
                  upiId: "",
                  upiPayLink: "",
                  qrDataUrl: "",
                  courseLink: "",
                });
              }}
              className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl transition font-medium ${
                activeTab === item.id
                  ? "bg-brand-accent/10 text-brand-accent border border-brand-accent/20"
                  : "text-white/50 hover:bg-white/5 hover:text-white"
              }`}
            >
              <item.icon size={20} />
              {item.label}
            </button>
          ))}
        </nav>

        <div className="absolute bottom-0 left-0 right-0 p-4 border-t border-white/10">
          <button
            onClick={async () => {
              await signOut(auth);
              onNavigate("login");
            }}
            className="w-full flex items-center gap-3 px-4 py-3 rounded-xl text-red-500 hover:bg-red-500/10 transition font-medium"
          >
            <LogOut size={20} />
            Logout
          </button>
        </div>
      </aside>

      <div className="flex-1 flex flex-col min-h-screen overflow-hidden">
        <header className="px-6 py-4 border-b border-white/10 flex items-center justify-between bg-black/50 backdrop-blur-md sticky top-0 z-50">
          <button onClick={() => setSidebarOpen(true)} className="lg:hidden p-2 -ml-2 text-white/50">
            <Menu size={24} />
          </button>
          <h2 className="font-space font-bold text-lg capitalize">{activeTab} Management</h2>
          <div className="flex items-center gap-4">
            <div className="hidden sm:flex flex-col items-end">
              <span className="text-sm font-bold">{user.name}</span>
              <span className="text-[10px] text-white/40 uppercase tracking-widest leading-none">
                Administrator
              </span>
            </div>
          </div>
        </header>

        <main className="flex-1 p-6 overflow-y-auto w-full max-w-5xl mx-auto">
          {activeTab === "dashboard" && (
            <div className="space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-500">
              <section className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
                <button
                  onClick={() => setActiveTab("batches")}
                  className="glass-card rounded-2xl p-6 border border-brand-accent/20 text-left hover:bg-brand-accent/5 transition"
                >
                  <p className="text-white/50 text-[10px] uppercase font-mono tracking-wider">Total Batches</p>
                  <p className="text-4xl font-bold text-brand-accent mt-2">{batches.length}</p>
                </button>
                <button
                  onClick={() => setActiveTab("payments")}
                  className="glass-card rounded-2xl p-6 border border-fuchsia-400/20 text-left hover:bg-fuchsia-400/5 transition"
                >
                  <p className="text-white/50 text-[10px] uppercase font-mono tracking-wider">
                    Total Submissions
                  </p>
                  <p className="text-4xl font-bold text-fuchsia-400 mt-2">{submissions.length}</p>
                </button>
                <button
                  onClick={() => setActiveTab("devices")}
                  className="glass-card rounded-2xl p-6 border border-blue-400/20 text-left hover:bg-blue-400/5 transition"
                >
                  <p className="text-white/50 text-[10px] uppercase font-mono tracking-wider">Active Users</p>
                  <p className="text-4xl font-bold text-blue-400 mt-2">{allUsers.length}</p>
                </button>
              </section>

              <section className="glass-card rounded-2xl p-6">
                <h3 className="text-lg font-space font-bold mb-4">Quick Summary</h3>
                <div className="space-y-4">
                  <button
                    onClick={() => setActiveTab("payments")}
                    className="w-full flex justify-between items-center p-4 bg-white/5 rounded-xl hover:bg-white/10 transition"
                  >
                    <span className="text-white/60">Pending Submissions</span>
                    <span className="px-3 py-1 bg-yellow-500/20 text-yellow-500 rounded-full text-xs font-bold">
                      {submissions.filter((k) => k.status === "pending").length}
                    </span>
                  </button>
                  <button
                    onClick={() => setActiveTab("devices")}
                    className="w-full flex justify-between items-center p-4 bg-white/5 rounded-xl hover:bg-white/10 transition"
                  >
                    <span className="text-white/60">Pending Devices</span>
                    <span className="px-3 py-1 bg-brand-accent/20 text-brand-accent rounded-full text-xs font-bold">
                      {allUsers
                        .flatMap((u) => Object.values(u.devices || {}))
                        .filter((d) => d.status === "pending").length}
                    </span>
                  </button>
                </div>
              </section>
            </div>
          )}

          {activeTab === "batches" && (
            <div className="space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-500">
              <section className="glass-card rounded-2xl p-6 border border-brand-accent/20">
                <div className="flex items-center justify-between mb-6">
                  <div className="flex items-center gap-2">
                    <Plus size={20} className="text-brand-accent" />
                    <h2 className="text-lg font-semibold">{editingBatchId ? "Edit Batch" : "Add New Batch"}</h2>
                  </div>
                </div>

                <form onSubmit={handleBatchSubmit} className="space-y-4">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="space-y-1.5">
                      <label className="text-xs text-white/50 font-mono uppercase pl-1">Batch Title</label>
                      <input
                        placeholder="e.g. NEET 2025 Droppers"
                        className="bg-white/5 rounded-xl px-4 py-3 w-full border border-white/10 outline-none focus:border-brand-accent"
                        value={batchForm.title || ""}
                        onChange={(e) => setBatchForm({ ...batchForm, title: e.target.value })}
                      />
                    </div>
                    <div className="space-y-1.5">
                      <label className="text-xs text-white/50 font-mono uppercase pl-1">Tag</label>
                      <input
                        placeholder="e.g. NEET 2025"
                        className="bg-white/5 rounded-xl px-4 py-3 w-full border border-white/10 outline-none focus:border-brand-accent"
                        value={batchForm.tag || ""}
                        onChange={(e) => setBatchForm({ ...batchForm, tag: e.target.value })}
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <div className="space-y-1.5">
                      <label className="text-xs text-white/50 font-mono uppercase pl-1">Actual Price</label>
                      <input
                        type="number"
                        placeholder="4999"
                        className="bg-white/5 rounded-xl px-4 py-3 w-full border border-white/10 outline-none focus:border-brand-accent"
                        value={batchForm.actualPrice || ""}
                        onChange={(e) => setBatchForm({ ...batchForm, actualPrice: Number(e.target.value) })}
                      />
                    </div>
                    <div className="space-y-1.5">
                      <label className="text-xs text-white/50 font-mono uppercase pl-1">Discount Price</label>
                      <input
                        type="number"
                        placeholder="2999"
                        className="bg-white/5 rounded-xl px-4 py-3 w-full border border-white/10 outline-none focus:border-brand-accent"
                        value={batchForm.discountPrice || ""}
                        onChange={(e) => setBatchForm({ ...batchForm, discountPrice: Number(e.target.value) })}
                      />
                    </div>
                    <div className="space-y-1.5">
                      <label className="text-xs text-white/50 font-mono uppercase pl-1">Institute</label>
                      <select
                        className="bg-white/5 rounded-xl px-4 py-3 w-full border border-white/10 outline-none focus:border-brand-accent text-white h-[46px]"
                        value={batchForm.institute || "all"}
                        onChange={(e) => setBatchForm({ ...batchForm, institute: e.target.value })}
                      >
                        <option value="all">All Institutes</option>
                        {activeInstList.map((inst) => (
                          <option key={inst.id} value={inst.id}>
                            {inst.name}
                          </option>
                        ))}
                      </select>
                    </div>
                  </div>

                  <div className="space-y-1.5">
                    <label className="text-xs text-white/50 font-mono uppercase pl-1">Batch Thumbnail</label>
                    <label className="cursor-pointer border border-dashed border-white/20 rounded-2xl p-6 flex flex-col items-center gap-3 hover:bg-white/5 transition relative overflow-hidden">
                      <input
                        type="file"
                        className="absolute inset-0 w-full h-full opacity-0 cursor-pointer z-10"
                        accept="image/*"
                        onChange={handleBatchThumbnailChange}
                      />
                      {batchForm.thumbnail === "uploading..." ? (
                        <RefreshCcw className="animate-spin text-brand-accent" />
                      ) : batchForm.thumbnail ? (
                        <div className="w-full h-40 rounded-xl overflow-hidden border border-white/10">
                          <img src={batchForm.thumbnail} className="w-full h-full object-cover" alt="thumbnail" />
                        </div>
                      ) : (
                        <>
                          <UploadCloud className="text-brand-accent" size={32} />
                          <span className="text-sm text-white/40">Upload banner image (800x400 recommended)</span>
                        </>
                      )}
                    </label>
                  </div>

                  <div className="space-y-1.5">
                    <label className="text-xs text-white/50 font-mono uppercase pl-1">Description (Optional)</label>
                    <textarea
                      placeholder="Enter batch descriptions..."
                      className="bg-white/5 rounded-xl px-4 py-3 w-full border border-white/10 outline-none focus:border-brand-accent h-20"
                      value={batchForm.description || ""}
                      onChange={(e) => setBatchForm({ ...batchForm, description: e.target.value })}
                    />
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="space-y-1.5">
                      <label className="text-xs text-white/50 font-mono uppercase pl-1">Custom UPI ID (Optional)</label>
                      <input
                        placeholder="e.g. batch@upi"
                        className="bg-white/5 rounded-xl px-4 py-3 w-full border border-white/10 outline-none focus:border-brand-accent"
                        value={batchForm.upiId || ""}
                        onChange={(e) => setBatchForm({ ...batchForm, upiId: e.target.value })}
                      />
                    </div>
                    <div className="space-y-1.5">
                      <label className="text-xs text-white/50 font-mono uppercase pl-1">Custom QR URL (Optional)</label>
                      <input
                        placeholder="https://example.com/qr.png"
                        className="bg-white/5 rounded-xl px-4 py-3 w-full border border-white/10 outline-none focus:border-brand-accent"
                        value={batchForm.qrDataUrl || ""}
                        onChange={(e) => setBatchForm({ ...batchForm, qrDataUrl: e.target.value })}
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="space-y-1.5">
                      <label className="text-xs text-white/50 font-mono uppercase pl-1">Custom UPI Pay Link (Optional)</label>
                      <input
                        placeholder="upi://pay?..."
                        className="bg-white/5 rounded-xl px-4 py-3 w-full border border-white/10 outline-none focus:border-brand-accent"
                        value={batchForm.upiPayLink || ""}
                        onChange={(e) => setBatchForm({ ...batchForm, upiPayLink: e.target.value })}
                      />
                    </div>
                    <div className="space-y-1.5">
                      <label className="text-xs text-white/50 font-mono uppercase pl-1">Course Live Link (Approved Users)</label>
                      <input
                        placeholder="https://zoom.us/j/..."
                        className="bg-white/5 rounded-xl px-4 py-3 w-full border border-white/10 outline-none focus:border-brand-accent"
                        value={batchForm.courseLink || ""}
                        onChange={(e) => setBatchForm({ ...batchForm, courseLink: e.target.value })}
                      />
                    </div>
                  </div>

                  <div className="flex gap-3 pt-2">
                    {editingBatchId && (
                      <button
                        type="button"
                        onClick={() => {
                          setEditingBatchId(null);
                          setBatchForm({
                            color: "#22c55e",
                            institute: "all",
                            members: "+1",
                            thumbnail: "",
                            description: "",
                            upiId: "",
                            upiPayLink: "",
                            qrDataUrl: "",
                            courseLink: "",
                          });
                        }}
                        className="flex-1 bg-white/5 text-white font-bold py-4 rounded-xl hover:bg-white/10 transition"
                      >
                        Cancel
                      </button>
                    )}
                    <button className="flex-1 bg-brand-accent text-black font-bold py-4 rounded-xl hover:opacity-90 transition">
                      {editingBatchId ? "Update Batch" : "Add New Batch"}
                    </button>
                  </div>
                </form>
              </section>

              <section className="space-y-4">
                <div className="flex items-center justify-between">
                  <h2 className="text-xl font-bold">Active Batches List</h2>
                  <button onClick={resetBatchesToDefault} className="text-xs text-white/40 underline hover:text-white transition">
                    Reset to Defaults
                  </button>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {batches.map((batch) => (
                    <div
                      key={batch.id}
                      className="glass-card rounded-2xl overflow-hidden border border-white/10 hover:border-brand-accent/30 transition shadow-lg"
                    >
                      <div className="h-32 w-full relative bg-white/5 border-b border-white/10">
                        {batch.thumbnail ? (
                          <img src={batch.thumbnail} className="w-full h-full object-cover" alt="thumbnail" />
                        ) : (
                          <div className="w-full h-full flex items-center justify-center opacity-20">
                            <School size={48} style={{ color: batch.color }} />
                          </div>
                        )}
                        <div className="absolute top-3 left-3 bg-black/60 backdrop-blur-md px-3 py-1 rounded-full border border-white/10">
                          <span className="text-[10px] font-mono font-bold text-white uppercase">{batch.tag}</span>
                        </div>
                      </div>
                      <div className="p-5 flex items-center justify-between">
                        <div className="min-w-0">
                          <h4 className="font-bold text-base truncate">{batch.title}</h4>
                          <p className="text-xs text-white/40 font-mono mt-1">
                            ₹{(batch.discountPrice || batch.actualPrice).toLocaleString()}
                          </p>
                        </div>
                        <div className="flex items-center gap-2">
                          <button
                            onClick={() => handleEditBatch(batch)}
                            className="p-2.5 rounded-xl bg-white/5 hover:bg-white/10 hover:text-brand-accent transition"
                          >
                            <Pen size={18} />
                          </button>
                          <button
                            onClick={() => handleDeleteBatch(batch.id)}
                            className="p-2.5 rounded-xl bg-red-500/10 text-red-500/50 hover:text-red-500 hover:bg-red-500/20 transition"
                          >
                            <Trash2 size={18} />
                          </button>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </section>
            </div>
          )}

          {activeTab === "ebooks" && (
            <div className="space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-500">
              <section className="glass-card rounded-2xl p-6 border border-brand-accent/20">
                <div className="flex items-center justify-between mb-6">
                  <div className="flex items-center gap-2">
                    <Library size={20} className="text-brand-accent" />
                    <h2 className="text-lg font-semibold">{editingEbookId ? "Edit Ebook" : "Add New Ebook"}</h2>
                  </div>
                </div>

                <form onSubmit={handleEbookSubmit} className="space-y-4">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="space-y-1.5">
                      <label className="text-xs text-white/50 font-mono uppercase pl-1">Book Title</label>
                      <input
                        placeholder="e.g. NCERT Physics Class 12"
                        className="bg-white/5 rounded-xl px-4 py-3 w-full border border-white/10 outline-none focus:border-brand-accent"
                        value={ebookForm.title}
                        onChange={(e) => setEbookForm({ ...ebookForm, title: e.target.value })}
                      />
                    </div>
                    <div className="space-y-1.5">
                      <label className="text-xs text-white/50 font-mono uppercase pl-1">Author</label>
                      <input
                        placeholder="e.g. H.C. Verma"
                        className="bg-white/5 rounded-xl px-4 py-3 w-full border border-white/10 outline-none focus:border-brand-accent"
                        value={ebookForm.author}
                        onChange={(e) => setEbookForm({ ...ebookForm, author: e.target.value })}
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="space-y-1.5">
                      <label className="text-xs text-white/50 font-mono uppercase pl-1">Category</label>
                      <input
                        placeholder="e.g. Physics, NEET, Class 10"
                        className="bg-white/5 rounded-xl px-4 py-3 w-full border border-white/10 outline-none focus:border-brand-accent"
                        value={ebookForm.category}
                        onChange={(e) => setEbookForm({ ...ebookForm, category: e.target.value })}
                      />
                    </div>
                    <div className="space-y-1.5">
                      <label className="text-xs text-white/50 font-mono uppercase pl-1">
                        Price (₹) — 0 or blank = Free
                      </label>
                      <input
                        type="number"
                        min="0"
                        placeholder="0"
                        className="bg-white/5 rounded-xl px-4 py-3 w-full border border-white/10 outline-none focus:border-brand-accent"
                        value={ebookForm.price || ""}
                        onChange={(e) => setEbookForm({ ...ebookForm, price: Number(e.target.value) })}
                      />
                    </div>
                  </div>

                  <div className="space-y-1.5">
                    <label className="text-xs text-white/50 font-mono uppercase pl-1">Description</label>
                    <textarea
                      placeholder="Short description of the book"
                      rows={3}
                      className="bg-white/5 rounded-xl px-4 py-3 w-full border border-white/10 outline-none focus:border-brand-accent resize-none"
                      value={ebookForm.description}
                      onChange={(e) => setEbookForm({ ...ebookForm, description: e.target.value })}
                    />
                  </div>

                  <div className="space-y-1.5">
                    <label className="text-xs text-white/50 font-mono uppercase pl-1">Direct PDF Link</label>
                    <input
                      placeholder="https://example.com/book.pdf"
                      className="bg-white/5 rounded-xl px-4 py-3 w-full border border-white/10 outline-none focus:border-brand-accent"
                      value={ebookForm.pdfLink}
                      onChange={(e) => setEbookForm({ ...ebookForm, pdfLink: e.target.value })}
                    />
                  </div>

                  <div className="space-y-1.5">
                    <label className="text-xs text-white/50 font-mono uppercase pl-1">Book Thumbnail</label>
                    <label className="flex items-center justify-center gap-3 border border-dashed border-white/15 rounded-xl py-6 cursor-pointer hover:bg-white/5 transition relative overflow-hidden">
                      <input
                        type="file"
                        className="absolute inset-0 w-full h-full opacity-0 cursor-pointer z-10"
                        accept="image/*"
                        onChange={onEbookThumbUpload}
                      />
                      {ebookForm.thumbnail === "uploading..." ? (
                        <RefreshCcw className="animate-spin text-brand-accent" />
                      ) : ebookForm.thumbnail ? (
                        <img src={ebookForm.thumbnail} className="h-20 rounded-lg object-cover" alt="book cover" />
                      ) : (
                        <div className="flex flex-col items-center gap-1 text-white/40">
                          <UploadCloud size={20} />
                          <span className="text-xs">Upload thumbnail</span>
                        </div>
                      )}
                    </label>
                  </div>

                  <div className="flex gap-3 pt-2">
                    <button type="submit" className="flex-1 bg-brand-accent text-black font-bold rounded-xl py-3">
                      {editingEbookId ? "Update Ebook" : "Add Ebook"}
                    </button>
                    {editingEbookId && (
                      <button
                        type="button"
                        onClick={() => {
                          setEditingEbookId(null);
                          setEbookForm({
                            title: "",
                            author: "",
                            category: "",
                            thumbnail: "",
                            description: "",
                            price: 0,
                            pdfLink: "",
                          });
                        }}
                        className="px-5 rounded-xl border border-white/10 text-white/60 hover:bg-white/5"
                      >
                        Cancel
                      </button>
                    )}
                  </div>
                </form>
              </section>

              <section className="space-y-3">
                <h2 className="text-lg font-semibold px-1">All Ebooks ({ebooks.length})</h2>
                {ebooks.length === 0 ? (
                  <p className="text-white/40 text-sm px-1">No ebooks added yet.</p>
                ) : (
                  ebooks.map((book) => (
                    <div key={book.id} className="glass-card rounded-xl p-4 flex items-center gap-4">
                      {book.thumbnail ? (
                        <img src={book.thumbnail} className="w-14 h-14 rounded-lg object-cover flex-shrink-0" alt="cover" />
                      ) : (
                        <div className="w-14 h-14 rounded-lg bg-white/5 flex items-center justify-center flex-shrink-0">
                          <Library size={20} className="text-white/30" />
                        </div>
                      )}
                      <div className="flex-1 min-w-0">
                        <p className="font-semibold truncate">{book.title}</p>
                        <p className="text-xs text-white/40 truncate">
                          {book.category || "Uncategorized"} • {book.price > 0 ? `₹${book.price}` : "Free"}
                        </p>
                      </div>
                      <div className="flex gap-2 flex-shrink-0">
                        <button
                          onClick={() => handleEditEbook(book)}
                          className="p-2 rounded-lg bg-white/5 hover:bg-white/10 text-white/60"
                        >
                          <Pen size={16} />
                        </button>
                        <button
                          onClick={() => handleDeleteEbook(book.id)}
                          className="p-2 rounded-lg bg-red-500/10 hover:bg-red-500/20 text-red-400"
                        >
                          <Trash2 size={16} />
                        </button>
                      </div>
                    </div>
                  ))
                )}
              </section>
            </div>
          )}

          {activeTab === "payments" && (
            <div className="space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-500">
              <section className="space-y-4">
                <div className="flex items-center justify-between sticky top-0 bg-[#09090b] py-2 z-10">
                  <h2 className="text-xl font-bold">Recent Payment Submissions</h2>
                  <button onClick={() => window.location.reload()} className="p-2.5 rounded-xl bg-white/5 hover:bg-white/10 transition">
                    <RefreshCcw size={18} className="text-white/40" />
                  </button>
                </div>

                {submissions.length === 0 ? (
                  <div className="p-12 glass-card rounded-2xl text-center text-white/30 italic">
                    No payment submissions found.
                  </div>
                ) : (
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    {submissions.map((sub) => (
                      <div
                        key={sub.id}
                        className="glass-card rounded-2xl border border-white/10 p-5 space-y-4 hover:border-white/20 transition shadow-xl"
                      >
                        <div className="flex justify-between items-start gap-4">
                          <div className="min-w-0">
                            <h4 className="font-bold text-base truncate">{sub.batchTitle}</h4>
                            <p className="text-xs text-white/40 font-mono mt-0.5 truncate">
                              {sub.userName} • {sub.userEmail}
                            </p>
                          </div>
                          <span
                            className={`px-3 py-1 rounded-full text-[10px] uppercase font-bold border shrink-0 ${
                              sub.status === "pending"
                                ? "bg-yellow-500/10 text-yellow-500 border-yellow-500/20"
                                : sub.status === "approved"
                                ? "bg-green-500/10 text-green-500 border-green-500/20"
                                : "bg-red-500/10 text-red-500 border-red-500/20"
                            }`}
                          >
                            {sub.status}
                          </span>
                        </div>

                        <div className="grid grid-cols-2 gap-3 bg-black/40 p-3 rounded-xl border border-white/5">
                          <div className="space-y-1">
                            <p className="text-[10px] text-white/40 uppercase font-mono">Amount</p>
                            <p className="text-brand-accent font-bold">₹{sub.amount}</p>
                          </div>
                          <div className="space-y-1">
                            <p className="text-[10px] text-white/40 uppercase font-mono">UTR ID</p>
                            <p className="text-white font-mono text-xs">{sub.utr}</p>
                          </div>
                        </div>

                        {sub.screenshot && (
                          <div className="space-y-2">
                            <p className="text-[10px] text-white/40 uppercase font-mono pl-1">Payment Proof</p>
                            <a
                              href={sub.screenshot}
                              target="_blank"
                              className="block w-full h-48 rounded-xl overflow-hidden border border-white/10 relative group bg-black/50"
                              rel="noreferrer"
                            >
                              <img src={sub.screenshot} className="w-full h-full object-contain" alt="screenshot" />
                              <div className="absolute inset-0 bg-black/60 opacity-0 group-hover:opacity-100 flex items-center justify-center transition font-bold text-xs">
                                View Full Proof
                              </div>
                            </a>
                          </div>
                        )}

                        {sub.status === "pending" ? (
                          <div className="space-y-3 pt-2">
                            {sub.batchId !== "WALLET_TOPUP" && (
                              <div className="space-y-1.5">
                                <label className="text-xs text-white/50 font-mono uppercase pl-1">
                                  Access Link for User
                                </label>
                                <input
                                  placeholder="Zoom / Drive / Live Portal link"
                                  className="bg-white/5 rounded-xl px-3 py-2 w-full border border-white/10 outline-none text-xs"
                                  value={accessLinks[sub.id] || ""}
                                  onChange={(e) => setAccessLinks({ ...accessLinks, [sub.id]: e.target.value })}
                                />
                              </div>
                            )}

                            <div className="flex gap-2">
                              <button
                                onClick={() => handleApproveSubmission(sub)}
                                className="flex-1 bg-green-500/20 text-green-500 py-3 rounded-xl text-xs font-bold hover:bg-green-500/30 transition flex items-center justify-center gap-2"
                              >
                                <Check size={14} /> Approve
                              </button>
                              <button
                                onClick={() => handleRejectSubmission(sub.id)}
                                className="flex-1 bg-red-500/10 text-red-500 py-3 rounded-xl text-xs font-bold hover:bg-red-500/20 transition flex items-center justify-center gap-2"
                              >
                                <X size={14} /> Reject
                              </button>
                            </div>
                          </div>
                        ) : sub.status === "approved" ? (
                          <button
                            onClick={() => handleRevokeSubmission(sub)}
                            className="w-full bg-red-500/10 text-red-500 py-3 rounded-xl text-xs font-bold hover:bg-red-500/20 transition flex items-center justify-center gap-2"
                          >
                            <X size={14} /> Revoke Course Access
                          </button>
                        ) : null}
                      </div>
                    ))}
                  </div>
                )}
              </section>
            </div>
          )}

          {activeTab === "institutes" && (
            <div className="space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-500">
              <section className="glass-card rounded-2xl p-6 border border-brand-accent/20">
                <div className="flex items-center gap-3 mb-6">
                  <Plus className="text-brand-accent" size={24} />
                  <h2 className="text-xl font-bold">Add New Institution</h2>
                </div>

                <div className="space-y-4">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="space-y-1.5">
                      <label className="text-xs text-white/50 font-mono uppercase pl-1">Institution Name</label>
                      <input
                        placeholder="e.g. Allen Career Institute"
                        className="bg-white/5 rounded-xl px-4 py-3 w-full border border-white/10 outline-none focus:border-brand-accent text-white"
                        value={newInst.name}
                        onChange={(e) => setNewInst({ ...newInst, name: e.target.value })}
                      />
                    </div>
                    <div className="space-y-1.5">
                      <label className="text-xs text-white/50 font-mono uppercase pl-1">Tag / Category</label>
                      <input
                        placeholder="e.g. JEE • Education"
                        className="bg-white/5 rounded-xl px-4 py-3 w-full border border-white/10 outline-none focus:border-brand-accent text-white"
                        value={newInst.tag}
                        onChange={(e) => setNewInst({ ...newInst, tag: e.target.value })}
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="space-y-1.5">
                      <label className="text-xs text-white/50 font-mono uppercase pl-1">Brand Color</label>
                      <div className="flex items-center gap-3">
                        <input
                          type="color"
                          value={newInst.color}
                          onChange={(e) => setNewInst({ ...newInst, color: e.target.value })}
                          className="w-12 h-12 rounded-xl border border-white/10 cursor-pointer bg-transparent p-1"
                        />
                        <span className="text-sm font-mono text-white/60">{newInst.color}</span>
                      </div>
                    </div>

                    <div className="space-y-1.5">
                      <label className="text-xs text-white/50 font-mono uppercase pl-1">Logo Image</label>
                      <label className="cursor-pointer flex items-center gap-3 px-4 py-3 rounded-xl bg-white/5 border border-white/10 hover:bg-white/10 transition relative overflow-hidden">
                        <input
                          type="file"
                          className="absolute inset-0 w-full h-full opacity-0 cursor-pointer z-10"
                          accept="image/*"
                          onChange={async (e) => {
                            const file = e.target.files?.[0];
                            if (file) {
                              if (file.size > 5 * 1024 * 1024) return alert("Max 5MB");
                              try {
                                const compressed = await compressImage(file, 200);
                                setNewInst((prev) => ({ ...prev, logo: compressed }));
                              } catch (err: any) {
                                alert("Failed: " + err.message);
                              }
                            }
                          }}
                        />
                        {newInst.logo ? (
                          <img
                            src={newInst.logo}
                            className="w-10 h-10 rounded-lg object-cover border border-white/20"
                            alt="logo"
                          />
                        ) : (
                          <UploadCloud size={20} className="text-white/40" />
                        )}
                        <span className="text-sm text-white/50">
                          {newInst.logo ? "Logo uploaded ✓" : "Upload logo (optional)"}
                        </span>
                      </label>
                    </div>
                  </div>
                </div>

                <button
                  onClick={addInstitution}
                  className="w-full bg-brand-accent text-black font-bold py-4 rounded-xl hover:opacity-90 transition mt-2"
                >
                  Add Institution
                </button>
              </section>

              <section className="glass-card rounded-2xl p-6 border border-fuchsia-400/20">
                <div className="flex items-center gap-3 mb-6">
                  <School className="text-fuchsia-400" size={24} />
                  <h2 className="text-xl font-bold">Branding: Institute Logos</h2>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {activeInstList.map((inst) => (
                    <div
                      key={inst.id}
                      className="flex items-center gap-4 p-4 bg-white/5 rounded-2xl border border-white/10 hover:border-fuchsia-400/30 transition shadow-lg"
                    >
                      <div className="relative group shrink-0">
                        {institutionLogos[inst.id] ? (
                          <div className="w-16 h-16 rounded-xl overflow-hidden border border-white/10 relative">
                            <img src={institutionLogos[inst.id]} className="w-full h-full object-cover" alt="logo" />
                            <button
                              onClick={() => handleLogoRemove(inst.id)}
                              className="absolute inset-0 bg-black/60 opacity-0 group-hover:opacity-100 flex items-center justify-center transition"
                            >
                              <X size={20} className="text-white" />
                            </button>
                          </div>
                        ) : (
                          <div className="w-16 h-16 rounded-xl bg-white/5 flex items-center justify-center text-white/10 border border-white/10">
                            <School size={24} />
                          </div>
                        )}
                      </div>

                      <div className="flex-1 min-w-0">
                        <p className="font-bold text-base truncate">{inst.name}</p>
                        <p className="text-[10px] text-white/40 uppercase font-mono tracking-widest mt-0.5">
                          Platform Assets
                        </p>
                      </div>

                      <div className="flex gap-2">
                        <label className="cursor-pointer px-4 py-2 rounded-xl bg-fuchsia-400/10 text-fuchsia-400 text-xs font-bold border border-fuchsia-400/20 hover:bg-fuchsia-400/20 transition">
                          <input
                            type="file"
                            className="opacity-0 w-0 h-0 absolute"
                            accept="image/*"
                            onChange={(e) => handleLogoUpload(inst.id, e)}
                          />
                          Update
                        </label>
                        {inst.id.startsWith("inst_") && (
                          <button
                            onClick={() => deleteInstitution(inst.id)}
                            className="px-3 py-2 rounded-xl bg-red-500/10 text-red-500 text-xs font-bold border border-red-500/20 hover:bg-red-500/20 transition"
                          >
                            Delete
                          </button>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              </section>
            </div>
          )}

          {activeTab === "recommend" && <RecommendPanel batches={batches} />}

          {activeTab === "walletupi" && (
            <div className="space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-500">
              <section className="glass-card rounded-2xl p-6 border border-brand-accent/20">
                <div className="flex items-center gap-3 mb-6">
                  <Wallet size={22} className="text-brand-accent" />
                  <div>
                    <h2 className="text-xl font-bold">Wallet UPI Settings</h2>
                    <p className="text-white/40 text-sm mt-0.5">
                      This UPI is shown to users when they top-up their wallet.
                    </p>
                  </div>
                </div>

                <form onSubmit={handleWalletUpiSubmit} className="space-y-5">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="space-y-1.5">
                      <label className="text-xs text-white/50 font-mono uppercase pl-1">Global UPI ID</label>
                      <input
                        placeholder="e.g. edutech@upi"
                        className="bg-white/5 rounded-xl px-4 py-3 w-full border border-white/10 outline-none focus:border-brand-accent text-white"
                        value={paymentConfig.upiId || ""}
                        onChange={(e) => setPaymentConfig({ ...paymentConfig, upiId: e.target.value })}
                      />
                      <p className="text-white/30 text-[10px] pl-1">
                        Used for wallet top-ups and as fallback for batch payments.
                      </p>
                    </div>

                    <div className="space-y-1.5">
                      <label className="text-xs text-white/50 font-mono uppercase pl-1">Payee / Account Name</label>
                      <input
                        placeholder="e.g. Edutech Academy"
                        className="bg-white/5 rounded-xl px-4 py-3 w-full border border-white/10 outline-none focus:border-brand-accent text-white"
                        value={paymentConfig.payeeName || ""}
                        onChange={(e) => setPaymentConfig({ ...paymentConfig, payeeName: e.target.value })}
                      />
                      <p className="text-white/30 text-[10px] pl-1">
                        Name shown in the user's UPI app during payment.
                      </p>
                    </div>
                  </div>

                  <div className="space-y-2">
                    <label className="text-xs text-white/50 font-mono uppercase pl-1">Global QR Code</label>
                    <div className="flex flex-col items-center gap-4">
                      <label className="cursor-pointer border border-dashed border-white/20 rounded-2xl p-6 flex flex-col items-center gap-3 hover:bg-white/5 transition relative overflow-hidden w-full">
                        <input
                          type="file"
                          className="absolute inset-0 w-full h-full opacity-0 cursor-pointer z-10"
                          accept="image/*"
                          onChange={handleWalletQrChange}
                        />
                        {paymentConfig.qrDataUrl ? (
                          <div className="flex flex-col items-center gap-3">
                            <div className="w-32 h-32 rounded-xl overflow-hidden border border-white/10 bg-white p-2">
                              <img src={paymentConfig.qrDataUrl} className="w-full h-full object-contain" alt="QR" />
                            </div>
                            <span className="text-xs text-white/40">Click to change QR image</span>
                          </div>
                        ) : (
                          <>
                            <UploadCloud className="text-brand-accent" size={32} />
                            <span className="text-sm text-white/40">Upload QR Code image (JPG/PNG)</span>
                            <span className="text-xs text-white/20">
                              This QR is shown in wallet top-up and batch payment screens
                            </span>
                          </>
                        )}
                      </label>
                      {/* FIX: Move "Remove Scanner" button OUTSIDE of the label! */}
                      {paymentConfig.qrDataUrl && (
                        <button
                          type="button"
                          onClick={() => {
                            if (!confirmRemoveQr) {
                              setConfirmRemoveQr(true);
                              setTimeout(() => setConfirmRemoveQr(false), 4000);
                            } else {
                              handleRemoveWalletQr();
                            }
                          }}
                          className={`px-4 py-2 rounded-lg text-xs font-bold transition self-center ${
                            confirmRemoveQr
                              ? "bg-red-600 text-white hover:bg-red-700 animate-pulse"
                              : "bg-red-500/10 text-red-400 hover:bg-red-500/20"
                          }`}
                        >
                          {confirmRemoveQr ? "Are you sure? Click again to Remove" : "Remove Scanner"}
                        </button>
                      )}
                    </div>
                  </div>

                  <div className="p-4 bg-brand-accent/5 border border-brand-accent/20 rounded-xl">
                    <p className="text-xs text-brand-accent font-mono font-semibold uppercase tracking-wider mb-1">
                      Current Active UPI
                    </p>
                    <p className="text-white font-space font-bold text-lg">{paymentConfig.upiId || "Not set"}</p>
                    {paymentConfig.payeeName && (
                      <p className="text-white/50 text-xs mt-0.5">{paymentConfig.payeeName}</p>
                    )}
                  </div>

                  <button
                    type="submit"
                    className="w-full bg-brand-accent text-black font-bold py-4 rounded-xl hover:opacity-90 transition flex items-center justify-center gap-2"
                  >
                    <Check size={18} />
                    Save Wallet UPI Settings
                  </button>
                </form>
              </section>
            </div>
          )}

          {activeTab === "devices" && (
            <div className="space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-500">
              <section className="space-y-6">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                  <div className="flex items-center gap-3">
                    <Smartphone size={24} className="text-brand-accent" />
                    <h2 className="text-xl font-bold">Device & Session Manager</h2>
                  </div>
                  <div className="relative w-full sm:w-64 group">
                    <List
                      size={18}
                      className="absolute left-3 top-1/2 -translate-y-1/2 text-white/30 group-focus-within:text-brand-accent transition"
                    />
                    <input
                      type="text"
                      placeholder="Search users or device..."
                      value={searchTerm}
                      onChange={(e) => setSearchTerm(e.target.value)}
                      className="w-full bg-white/5 border border-white/10 rounded-xl pl-10 pr-4 py-2.5 text-sm outline-none focus:border-brand-accent transition"
                    />
                  </div>
                </div>

                <div className="space-y-4">
                  <h3 className="text-xs font-mono text-yellow-500 uppercase tracking-widest pl-1">
                    Action Required
                  </h3>
                  {(() => {
                    const actionNeededList = allUsers
                      .flatMap((u) =>
                        (Object.values(u.devices || {}) as Device[])
                          .filter((d) => d.status === "pending" || d.status === "revoked")
                          .map((d) => ({ user: u, device: d }))
                      )
                      .filter((item) => {
                        const q = searchTerm.toLowerCase();
                        return (
                          (item.user.name || "").toLowerCase().includes(q) ||
                          (item.user.email || "").toLowerCase().includes(q) ||
                          (item.device.userAgent || "").toLowerCase().includes(q)
                        );
                      });

                    if (actionNeededList.length === 0) {
                      return (
                        <div className="p-8 glass-card rounded-2xl text-center text-white/20 italic border border-dashed border-white/10">
                          All systems clear. No pending device requests.
                        </div>
                      );
                    }

                    return (
                      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
                        {actionNeededList.map(({ user: u, device: d }, idx) => (
                          <div
                            key={idx}
                            className={`glass-card rounded-2xl p-5 space-y-4 border transition hover:border-white/20 ${
                              d.status === "revoked" ? "border-red-500/20" : "border-yellow-500/20"
                            }`}
                          >
                            <div className="flex justify-between items-start gap-4">
                              <div className="min-w-0">
                                <h4 className="font-bold text-base truncate">{u.name}</h4>
                                <p className="text-xs text-white/40 font-mono mt-0.5 truncate">{u.email}</p>
                              </div>
                              <span
                                className={`px-2.5 py-1 border rounded-full text-[10px] font-bold uppercase ${
                                  d.status === "revoked"
                                    ? "bg-red-500/10 text-red-500 border-red-500/20"
                                    : "bg-yellow-500/10 text-yellow-500 border-yellow-500/20"
                                }`}
                              >
                                {d.status}
                              </span>
                            </div>

                            <div className="p-3 bg-white/5 rounded-xl border border-white/5">
                              <p className="text-[10px] text-white/30 uppercase font-mono mb-1">Device Client Info</p>
                              <p className="text-[11px] text-white/60 leading-relaxed font-mono">
                                {d.userAgent || "Unknown System"}
                              </p>
                              <p className="text-[9px] text-white/30 font-mono mt-2 italic">
                                Last Login: {new Date(d.lastLogin).toLocaleString()}
                              </p>
                            </div>

                            <div className="flex gap-2">
                              <button
                                onClick={() => handleDeviceApprove(u.uid, d.deviceId)}
                                className="flex-1 bg-brand-accent/20 text-brand-accent py-3 rounded-xl text-xs font-bold hover:bg-brand-accent/30 transition flex items-center justify-center gap-2"
                              >
                                <Check size={14} /> Approve
                              </button>
                              <button
                                onClick={() => handleDeviceDelete(u.uid, d.deviceId)}
                                className="flex-1 bg-white/10 text-white/60 py-3 rounded-xl text-xs font-bold hover:bg-white/20 transition flex items-center justify-center gap-2"
                              >
                                <Trash2 size={14} /> Clear
                              </button>
                            </div>
                          </div>
                        ))}
                      </div>
                    );
                  })()}
                </div>

                <div className="pt-8 border-t border-white/10 space-y-4">
                  <h3 className="text-xs font-mono text-green-500 uppercase tracking-widest pl-1">
                    Trusted Session Log
                  </h3>
                  <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
                    {allUsers
                      .filter((u) => {
                        const q = searchTerm.toLowerCase();
                        return (u.name || "").toLowerCase().includes(q) || (u.email || "").toLowerCase().includes(q);
                      })
                      .map((u) => {
                        const approvedDevices = (Object.values(u.devices || {}) as Device[]).filter((d) => d.status === "approved");
                        if (approvedDevices.length === 0) return null;

                        return (
                          <div
                            key={u.uid}
                            className="glass-card rounded-2xl p-5 space-y-3 hover:border-white/20 transition border border-white/5"
                          >
                            <div className="flex items-center gap-3">
                              <div className="w-10 h-10 rounded-full bg-brand-accent/20 flex items-center justify-center border border-brand-accent/30 text-brand-accent font-bold">
                                {u.name?.[0]?.toUpperCase()}
                              </div>
                              <div className="min-w-0 flex-1">
                                <p className="font-bold text-sm truncate">{u.name}</p>
                                <p className="text-[10px] text-white/40 truncate font-mono">{u.email}</p>
                              </div>
                            </div>

                            <div className="space-y-2">
                              {approvedDevices.map((d, idx) => (
                                <div
                                  key={d.deviceId || idx}
                                  className="flex items-center justify-between bg-black/40 rounded-xl p-3 border border-white/5 group"
                                >
                                  <div className="min-w-0 pr-4">
                                    <p className="text-[11px] text-white/70 truncate font-mono">
                                      {(d.userAgent || "Unknown Device").split(")")[0] + ")"}
                                    </p>
                                    <p className="text-[9px] text-green-400 font-bold mt-0.5 tracking-widest uppercase opacity-80">
                                      Connected
                                    </p>
                                  </div>

                                  <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition">
                                    <button
                                      onClick={() => handleDeviceRevoke(u.uid, d.deviceId)}
                                      className="p-2 text-red-500/50 hover:text-red-500 hover:bg-red-500/10 rounded-lg transition shrink-0"
                                      title="Revoke Access"
                                    >
                                      <X size={16} />
                                    </button>
                                    <button
                                      onClick={() => handleDeviceDelete(u.uid, d.deviceId)}
                                      className="p-2 text-white/30 hover:text-white hover:bg-white/10 rounded-lg transition shrink-0"
                                      title="Delete Record"
                                    >
                                      <Trash2 size={16} />
                                    </button>
                                  </div>
                                </div>
                              ))}
                            </div>
                          </div>
                        );
                      })}
                  </div>
                </div>
              </section>
            </div>
          )}
        </main>
      </div>
    </div>
  );
}
