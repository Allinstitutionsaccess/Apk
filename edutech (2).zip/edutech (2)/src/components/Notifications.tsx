import { Submission } from "../types";
import { Menu, Bell, Wallet, CircleCheckBig, CircleX, Clock } from "lucide-react";
import BottomNav from "./BottomNav";

interface NotificationsProps {
  submissions: Submission[];
  user: any;
  onNavigate: (view: string) => void;
}

export default function Notifications({ submissions, user, onNavigate }: NotificationsProps) {
  const userSubmissions = submissions.filter((s) => s.userUid === user.uid);
  const triggerMenu = () => window.dispatchEvent(new CustomEvent("openMenu"));

  return (
    <div className="flex flex-col min-h-screen pb-32">
      <header className="fixed top-0 left-0 right-0 z-50 bg-black/60 backdrop-blur-lg border-b border-white/10 flex justify-between items-center px-6 py-4 max-w-[460px] mx-auto">
        <div className="flex items-center gap-3">
          <button className="text-[#cf3] cursor-pointer" onClick={triggerMenu}>
            <Menu size={24} />
          </button>
          <span className="font-space font-black text-2xl tracking-tighter text-[#cf3]">
            Edutech
          </span>
        </div>
      </header>

      <main className="pt-28 px-5">
        <section className="mb-6">
          <h1 className="font-space text-3xl font-bold tracking-tight">Alerts</h1>
          <p className="text-white/40 text-sm mt-1">
            Payment updates & course announcements.
          </p>
        </section>

        <div className="space-y-3">
          {userSubmissions.length === 0 ? (
            <div className="flex flex-col items-center justify-center py-20 text-center gap-4">
              <Bell size={48} className="text-white/10" />
              <p className="text-white/30 text-sm">No notifications available.</p>
            </div>
          ) : (
            userSubmissions.map((sub) => {
              const config = (
                {
                  pending: { icon: Clock, color: "text-yellow-500", bg: "bg-yellow-500/10", title: "Payment Processing" },
                  approved: { icon: CircleCheckBig, color: "text-emerald-500", bg: "bg-emerald-500/10", title: "Payment Approved" },
                  rejected: { icon: CircleX, color: "text-red-500", bg: "bg-red-500/10", title: "Payment Rejected" },
                } as any
              )[sub.status];

              const Icon = config.icon;

              return (
                <div key={sub.id} className="flex items-start gap-4 p-4 rounded-2xl border border-white/5 bg-white/[0.02] hover:bg-white/5 transition">
                  <div className={`w-10 h-10 rounded-full flex items-center justify-center shrink-0 border border-white/5 ${config.bg}`}>
                    <Icon className={config.color} size={20} />
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="font-space font-semibold text-sm text-white mb-0.5">{config.title}</p>
                    <p className="text-white/50 text-xs leading-relaxed">
                      {sub.status === "pending" && `Your submission for ${sub.batchTitle} is being reviewed.`}
                      {sub.status === "approved" && `Congratulations! Your payment for ${sub.batchTitle} was verified.`}
                      {sub.status === "rejected" && `Unfortunately, your payment for ${sub.batchTitle} was rejected. Please contact support.`}
                    </p>
                    <p className="text-white/20 text-[10px] mt-2 font-mono uppercase">
                      {new Date(sub.createdAt).toLocaleDateString()} •{" "}
                      {new Date(sub.createdAt).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}
                    </p>
                  </div>
                </div>
              );
            })
          )}
        </div>
      </main>
      <BottomNav active="notifications" onNavigate={onNavigate} />
    </div>
  );
}
