export interface Device {
  deviceId: string;
  userAgent: string;
  lastLogin: string;
  status: "pending" | "approved" | "revoked";
}

export interface User {
  uid: string;
  email: string;
  name: string;
  isAdmin?: boolean;
  phone?: string;
  inviteCode?: string;
  referredBy?: string | null;
  referralRewardSent?: boolean;
  profilePicture?: string;
  devices?: Record<string, Device>;
}

export interface Batch {
  id: string;
  title: string;
  tag: string;
  members: string;
  color: string;
  institute: string;
  actualPrice: number;
  discountPrice: number;
  thumbnail: string;
  description?: string;
  upiId?: string;
  upiPayLink?: string;
  qrDataUrl?: string;
  courseLink?: string;
}

export interface Ebook {
  id: string;
  title: string;
  author?: string;
  category?: string;
  thumbnail?: string;
  description?: string;
  price: number;
  pdfLink?: string;
}

export interface Submission {
  id: string;
  batchId: string;
  batchTitle: string;
  amount: number;
  utr: string;
  upiId: string;
  screenshot?: string;
  userUid: string;
  userName: string;
  userEmail: string;
  status: "pending" | "approved" | "rejected";
  createdAt: string;
  updatedAt?: string;
  accessLink?: string;
}

export interface Institution {
  id: string;
  name: string;
  tag: string;
  color: string;
  initial: string;
  logo?: string;
}

export interface Wallet {
  balance: number;
  history: Array<{
    amount: number;
    reason: string;
    date: string;
  }>;
}
