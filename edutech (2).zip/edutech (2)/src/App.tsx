import { useEffect, useState } from "react";
import { User as FirebaseUser, onAuthStateChanged } from "firebase/auth";
import { ref, get, update, set } from "firebase/database";
import { auth, db } from "./firebase";
import { User, Batch, Ebook, Submission } from "./types";
import { getDeviceId } from "./utils";
import { qs } from "./firebase_helper";
import { ADMIN_EMAIL } from "./data";

// Components
import Splash from "./components/Splash";
import Login from "./components/Login";
import Register from "./components/Register";
import Home from "./components/Home";
import InstituteSelect from "./components/InstituteSelect";
import BatchSelect from "./components/BatchSelect";
import MyCourses from "./components/MyCourses";
import Ebooks from "./components/Ebooks";
import PaymentScreen from "./components/PaymentScreen";
import WalletPage from "./components/WalletPage";
import ReferPage from "./components/ReferPage";
import ProfilePage from "./components/ProfilePage";
import SecurityPage from "./components/SecurityPage";
import DeviceApproval from "./components/DeviceApproval";
import AdminPanel from "./components/AdminPanel";
import Notifications from "./components/Notifications";
import SidebarMenu from "./components/SidebarMenu";

export default function App() {
  const [loading, setLoading] = useState(true);
  const [splashComplete, setSplashComplete] = useState(false);
  const [fbUser, setFbUser] = useState<FirebaseUser | null>(null);
  const [dbUser, setDbUser] = useState<User | null>(null);

  // Lists
  const [batches, setBatches] = useState<Batch[]>([]);
  const [ebooks, setEbooks] = useState<Ebook[]>([]);
  const [submissions, setSubmissions] = useState<Submission[]>([]);

  // Navigation state
  const [currentView, setCurrentView] = useState("home");
  const [selectedBatch, setSelectedBatch] = useState<Batch | null>(null);
  const [selectedInstitute, setSelectedInstitute] = useState<{ id: string; name: string } | null>(null);
  const [menuOpen, setMenuOpen] = useState(false);

  useEffect(() => {
    const handleOpenMenu = () => setMenuOpen(true);
    window.addEventListener("openMenu", handleOpenMenu);
    return () => {
      window.removeEventListener("openMenu", handleOpenMenu);
    };
  }, []);

  // Firebase auth state observer
  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (user) => {
      setFbUser(user);
      if (!user) {
        setDbUser(null);
        setLoading(false);
        return;
      }

      // Quick-fetch user profile to register current device
      const userRef = ref(db, `users/${user.uid}`);
      let userSnap = await get(userRef);

      const isSystemAdmin = user.email?.toLowerCase() === ADMIN_EMAIL.toLowerCase();

      if (!userSnap.exists() && isSystemAdmin) {
        // Create admin user record if it doesn't exist
        await set(userRef, {
          name: "Admin",
          email: ADMIN_EMAIL,
          role: "admin",
          isAdmin: true,
          createdAt: new Date().toISOString(),
        });
        // Re-fetch userSnap
        userSnap = await get(userRef);
      }

      if (userSnap.exists()) {
        const uVal = userSnap.val();
        const devId = getDeviceId();
        const devices = uVal.devices || {};

        // If the user's role is admin, they don't have device-approval restrictions or they approve automatically
        const isUserAdmin = uVal.role === "admin" || uVal.isAdmin === true || isSystemAdmin;
        const defaultStatus = isUserAdmin ? "approved" : "pending";

        if (!devices[devId]) {
          // Register device
          await update(ref(db, `users/${user.uid}/devices/${devId}`), {
            deviceId: devId,
            userAgent: navigator.userAgent,
            lastLogin: new Date().toISOString(),
            status: defaultStatus,
          });
        } else {
          // Update last login
          await update(ref(db, `users/${user.uid}/devices/${devId}`), {
            lastLogin: new Date().toISOString(),
          });
        }
      }

      // Establish live listener on active user object
      const unsubUser = qs(ref(db, `users/${user.uid}`), (snap) => {
        if (snap.exists()) {
          setDbUser({ ...snap.val(), uid: user.uid });
          setLoading(false);
        } else {
          if (isSystemAdmin) {
            // Auto initialize or re-initialize to avoid race conditions/deletion
            set(ref(db, `users/${user.uid}`), {
              name: "Admin",
              email: ADMIN_EMAIL,
              role: "admin",
              isAdmin: true,
              createdAt: new Date().toISOString(),
            });
          } else {
            auth.signOut();
            setLoading(false);
          }
        }
      });

      return () => {
        unsubUser();
      };
    });

    return () => {
      unsubscribe();
    };
  }, []);

  // Real-time listener for app batches
  useEffect(() => {
    const unsubBatches = qs(ref(db, "batches"), (snap) => {
      if (snap.exists()) {
        const list = Object.entries(snap.val()).map(([id, b]: any) => ({
          ...b,
          id: b.id || id,
        }));
        setBatches(list);
      } else {
        setBatches([]);
      }
    });

    return () => {
      unsubBatches();
    };
  }, []);

  // Real-time listener for study Ebooks
  useEffect(() => {
    const unsubEbooks = qs(ref(db, "ebooks"), (snap) => {
      if (snap.exists()) {
        const list = Object.entries(snap.val()).map(([id, eb]: any) => ({
          ...eb,
          id: eb.id || id,
        }));
        setEbooks(list);
      } else {
        setEbooks([]);
      }
    });

    return () => {
      unsubEbooks();
    };
  }, []);

  // Real-time listener for payment verification submissions
  useEffect(() => {
    const unsubSubmissions = qs(ref(db, "paymentSubmissions"), (snap) => {
      if (snap.exists()) {
        const list = Object.entries(snap.val()).map(([id, s]: any) => ({
          ...s,
          id: s.id || id,
        }));
        setSubmissions(list);
      } else {
        setSubmissions([]);
      }
    });

    return () => {
      unsubSubmissions();
    };
  }, []);

  // Show beautiful introductory splash screen first
  if (!splashComplete) {
    return <Splash onComplete={() => setSplashComplete(true)} />;
  }

  if (loading) {
    return <Splash showButton={false} />;
  }

  // Handle unauthenticated user state
  if (!fbUser) {
    if (currentView === "register") {
      return (
        <Register
          onNavigate={setCurrentView}
        />
      );
    }
    return <Login onNavigate={setCurrentView} onLoginSuccess={(u) => setDbUser(u)} />;
  }

  // Handle cases where user data might be in transition/creating
  if (!dbUser) {
    return <Splash showButton={false} />;
  }

  // Check device approval security state (exclude admin bypass)
  const devId = getDeviceId();
  const currentDevice = dbUser.devices?.[devId];
  const isSystemAdmin = dbUser.role === "admin" || dbUser.isAdmin === true || dbUser.email?.toLowerCase() === ADMIN_EMAIL.toLowerCase();
  const isApproved = isSystemAdmin || currentDevice?.status === "approved";

  if (!isApproved) {
    return <DeviceApproval user={dbUser} onNavigate={setCurrentView} />;
  }

  // Redirect Admin user straight to admin workspace, keeping view within Admin scopes
  if (isSystemAdmin) {
    return (
      <AdminPanel
        user={dbUser}
        batches={batches}
        ebooks={ebooks}
        submissions={submissions}
        onNavigate={setCurrentView}
      />
    );
  }

  // Render client pages based on state
  let clientContent = null;
  switch (currentView) {
    case "institute":
      clientContent = (
        <InstituteSelect
          onNavigate={setCurrentView}
          onSelect={(id, name) => {
            setSelectedInstitute({ id, name });
            setCurrentView("batch");
          }}
        />
      );
      break;

    case "batch":
      clientContent = (
        <BatchSelect
          institute={selectedInstitute}
          batches={batches}
          submissions={submissions}
          user={dbUser}
          onNavigate={setCurrentView}
          onSelectBatch={(b) => {
            setSelectedBatch(b);
            setCurrentView("payment");
          }}
        />
      );
      break;

    case "payment":
      if (!selectedBatch) {
        setCurrentView("batch");
        return null;
      }
      clientContent = (
        <PaymentScreen
          batch={selectedBatch}
          user={dbUser}
          onNavigate={setCurrentView}
        />
      );
      break;

    case "mycourses":
      clientContent = (
        <MyCourses
          submissions={submissions}
          batches={batches}
          user={dbUser}
          onNavigate={setCurrentView}
        />
      );
      break;

    case "ebooks":
      clientContent = (
        <Ebooks
          ebooks={ebooks}
          onNavigate={setCurrentView}
        />
      );
      break;

    case "wallet":
      clientContent = (
        <WalletPage
          user={dbUser}
          onNavigate={setCurrentView}
        />
      );
      break;

    case "refer":
      clientContent = (
        <ReferPage
          user={dbUser}
          onNavigate={setCurrentView}
        />
      );
      break;

    case "profile":
      clientContent = (
        <ProfilePage
          user={dbUser}
          onNavigate={setCurrentView}
        />
      );
      break;

    case "security":
      clientContent = (
        <SecurityPage
          user={dbUser}
          onNavigate={setCurrentView}
        />
      );
      break;

    case "notifications":
      clientContent = (
        <Notifications
          submissions={submissions}
          user={dbUser}
          onNavigate={setCurrentView}
        />
      );
      break;

    case "home":
    default:
      clientContent = (
        <Home
          user={dbUser}
          batches={batches}
          onNavigate={setCurrentView}
          onSelectBatch={(b) => {
            setSelectedBatch(b);
            setCurrentView("payment");
          }}
          onSelectInstitute={(id, name) => {
            setSelectedInstitute({ id, name });
            setCurrentView("batch");
          }}
        />
      );
      break;
  }

  return (
    <>
      {clientContent}
      <SidebarMenu
        isOpen={menuOpen}
        onClose={() => setMenuOpen(false)}
        onNavigate={setCurrentView}
        user={dbUser}
      />
    </>
  );
}
