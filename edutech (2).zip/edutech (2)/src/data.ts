import { Institution, Batch } from "./types";

export const defaultInstitutions: Institution[] = [
  { id: "pw", name: "Physics Wallah", tag: "ALL Classes • Education", color: "#1d4ed8", initial: "PW" },
  { id: "vibrant", name: "Vibrant Academy", tag: "JEE • Education", color: "#dc2626", initial: "VA" },
  { id: "next", name: "Next Toppers", tag: "Board Exams • Education", color: "#9333ea", initial: "NT" },
  { id: "mission", name: "Mission Jeet", tag: "JEE / NEET • Education", color: "#059669", initial: "MJ" }
];

export const tx: Batch[] = [
  { id: "b1", title: "Udaan 2027", tag: "Class 10th", members: "+3", color: "#22c55e", institute: "all", actualPrice: 4999, discountPrice: 1999, thumbnail: "" },
  { id: "b2", title: "UDAY 2027", tag: "Class 11th", members: "+4", color: "#3b82f6", institute: "all", actualPrice: 6999, discountPrice: 2999, thumbnail: "" },
  { id: "b3", title: "Arjuna NEET 2027", tag: "NEET", members: "+5", color: "#ec4899", institute: "all", actualPrice: 9999, discountPrice: 3999, thumbnail: "" },
  { id: "b4", title: "Arjuna JEE 2027", tag: "JEE", members: "+4", color: "#f59e0b", institute: "all", actualPrice: 9999, discountPrice: 3499, thumbnail: "" }
];

export const ADMIN_EMAIL = "araukumaf@gmail.com";
export const ADMIN_PASSWORD = "0plm.0plm.";
export const REFERRAL_REWARD = 50;

export const defaultQr = {
  upiId: "edutech-pay@upi",
  payeeName: "Edutech Academy",
  qrDataUrl: ""
};
