import { initializeApp } from "firebase/app";
import { getAuth } from "firebase/auth";
import { getDatabase } from "firebase/database";

const firebaseConfig = {
  apiKey: "AIzaSyAoG8eh5ui4Ls11QlDH0Yjgct97Etz_u7U",
  authDomain: "edutech-67221.firebaseapp.com",
  databaseURL: "https://edutech-67221-default-rtdb.firebaseio.com",
  projectId: "edutech-67221",
  storageBucket: "edutech-67221.firebasestorage.app",
  messagingSenderId: "362053274378",
  appId: "1:362053274378:web:98c3a43fc7af7aef7788f3"
};

export const app = initializeApp(firebaseConfig);
export const auth = getAuth(app);
export const db = getDatabase(app);
